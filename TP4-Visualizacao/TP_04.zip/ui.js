document.addEventListener("DOMContentLoaded", () => {
    const hexBody = document.getElementById("hexBody");
    const fileSizeLabel = document.getElementById("fileSizeLabel");
    
    const tooltip = document.createElement("div");
    tooltip.className = "byte-tooltip";
    document.body.appendChild(tooltip);

    const consoleBody = document.getElementById("consoleBody");
    const btnClearConsole = document.getElementById("btnClearConsole");
    const btnResetDB = document.getElementById("btnResetDB");

    const tabButtons = document.querySelectorAll(".nav-link");
    const tabContents = document.querySelectorAll(".tab-content");

    const coursesList = document.getElementById("coursesList");
    const courseForm = document.getElementById("courseForm");
    const courseIdInput = document.getElementById("courseId");
    const courseNameInput = document.getElementById("courseName");
    const courseDateInput = document.getElementById("courseDate");
    const courseStatusSelect = document.getElementById("courseStatus");
    const courseUserIdInput = document.getElementById("courseUserId");
    const courseShareCodeInput = document.getElementById("courseShareCode");
    const courseDescTextarea = document.getElementById("courseDesc");
    const formTitle = document.getElementById("formTitle");
    const btnSubmitCourse = document.getElementById("btnSubmitCourse");
    const btnCancelEdit = document.getElementById("btnCancelEdit");

    const searchIdInput = document.getElementById("searchId");
    const btnSearchId = document.getElementById("btnSearchId");
    const searchNameInput = document.getElementById("searchName");
    const btnSearchName = document.getElementById("btnSearchName");
    const searchResults = document.getElementById("searchResults");

    // Navegação por abas
    tabButtons.forEach(button => {
        button.addEventListener("click", () => {
            const targetTab = button.getAttribute("data-tab");
            
            tabButtons.forEach(btn => btn.classList.remove("active"));
            tabContents.forEach(content => content.classList.remove("active"));
            
            button.classList.add("active");
            document.getElementById(targetTab).classList.add("active");

            // Atualiza a listagem ao exibir a aba correspondente
            if (targetTab === "tab-list") {
                renderCoursesList();
            }
        });
    });

    // Renderiza a grade de bytes (Hexadecimal e ASCII)
    function renderHexViewer() {
        const bytes = getDatabaseBytes();
        const map = mapDatabaseBytes();
        
        fileSizeLabel.textContent = `${bytes.length} bytes`;
        hexBody.innerHTML = "";

        if (bytes.length === 0) {
            hexBody.innerHTML = `<div style="color: #7c7c8a; text-align: center; padding: 20px;">Arquivo vazio.</div>`;
            return;
        }

        const numRows = Math.ceil(bytes.length / 16);

        for (let r = 0; r < numRows; r++) {
            const rowStart = r * 16;
            const rowOffsetStr = rowStart.toString(16).toUpperCase().padStart(8, '0');

            const rowDiv = document.createElement("div");
            rowDiv.className = "hex-row";

            const offsetDiv = document.createElement("div");
            offsetDiv.className = "row-offset";
            offsetDiv.textContent = `${rowOffsetStr}:`;
            rowDiv.appendChild(offsetDiv);

            const bytesGridDiv = document.createElement("div");
            bytesGridDiv.className = "row-bytes";

            for (let c = 0; c < 16; c++) {
                const index = rowStart + c;
                const byteSpan = document.createElement("span");
                
                if (index < bytes.length) {
                    const byteVal = bytes[index];
                    const mapping = map[index] || {};
                    
                    byteSpan.className = "byte-cell";
                    byteSpan.textContent = byteVal.toString(16).toUpperCase().padStart(2, '0');
                    byteSpan.dataset.index = index;

                    if (mapping.type === 'header') {
                        byteSpan.classList.add("c-header");
                    } else if (mapping.type === 'lapide') {
                        byteSpan.classList.add(byteVal === 0x20 ? "c-lapide-act" : "c-lapide-del");
                    } else if (mapping.type === 'size') {
                        byteSpan.classList.add("c-size");
                    } else if (mapping.type === 'deleted_data') {
                        byteSpan.classList.add("c-deleted-data");
                    } else if (mapping.type === 'field') {
                        byteSpan.classList.add(`c-${mapping.fieldName.replace('_len', '')}`);
                    }
                } else {
                    byteSpan.className = "byte-cell empty";
                    byteSpan.textContent = "..";
                }
                bytesGridDiv.appendChild(byteSpan);
            }
            rowDiv.appendChild(bytesGridDiv);

            const asciiDiv = document.createElement("div");
            asciiDiv.className = "row-ascii";

            for (let c = 0; c < 16; c++) {
                const index = rowStart + c;
                const asciiSpan = document.createElement("span");
                asciiSpan.className = "ascii-cell";
                
                if (index < bytes.length) {
                    const byteVal = bytes[index];
                    const mapping = map[index] || {};
                    asciiSpan.dataset.index = index;

                    if (byteVal >= 32 && byteVal <= 126) {
                        asciiSpan.textContent = String.fromCharCode(byteVal);
                    } else {
                        asciiSpan.textContent = ".";
                    }

                    if (mapping.type === 'header') {
                        asciiSpan.classList.add("c-header");
                    } else if (mapping.type === 'lapide') {
                        asciiSpan.classList.add(byteVal === 0x20 ? "c-lapide-act" : "c-lapide-del");
                    } else if (mapping.type === 'size') {
                        asciiSpan.classList.add("c-size");
                    } else if (mapping.type === 'deleted_data') {
                        asciiSpan.classList.add("c-deleted-data");
                    } else if (mapping.type === 'field') {
                        asciiSpan.classList.add(`c-${mapping.fieldName.replace('_len', '')}`);
                    }
                } else {
                    asciiSpan.textContent = ".";
                    asciiSpan.className = "ascii-cell empty";
                }
                asciiDiv.appendChild(asciiSpan);
            }
            rowDiv.appendChild(asciiDiv);

            hexBody.appendChild(rowDiv);
        }

        setupHexHoverListeners();
    }

    // Gerencia o tooltip e o destaque de bytes relacionados
    function setupHexHoverListeners() {
        const cells = document.querySelectorAll(".byte-cell:not(.empty), .ascii-cell:not(.empty)");
        const map = mapDatabaseBytes();

        cells.forEach(cell => {
            cell.addEventListener("mouseenter", (e) => {
                const index = parseInt(e.target.dataset.index);
                const mapping = map[index];
                if (!mapping) return;

                const decVal = mapping.value;
                const binVal = decVal.toString(2).padStart(8, '0');
                
                let asciiText = '';
                if (decVal >= 32 && decVal <= 126) {
                    asciiText = `'${String.fromCharCode(decVal)}'`;
                } else if (decVal === 0) {
                    asciiText = `NUL (0x00)`;
                } else if (decVal === 0x20) {
                    asciiText = `Espaço (0x20)`;
                } else {
                    asciiText = `Não-visível`;
                }

                tooltip.innerHTML = `
                    <div><strong>Offset:</strong> 0x${index.toString(16).toUpperCase().padStart(4, '0')} (${index})</div>
                    <div><strong>Hex:</strong> 0x${mapping.value.toString(16).toUpperCase().padStart(2, '0')}</div>
                    <div><strong>Decimal:</strong> ${decVal} (${binVal})</div>
                    <div><strong>ASCII:</strong> ${asciiText}</div>
                    <div class="desc-text">${mapping.desc}</div>
                `;
                
                tooltip.style.display = "block";

                // Destaca todos os bytes pertencentes ao mesmo campo ou registro físico
                cells.forEach(c => {
                    const cIdx = parseInt(c.dataset.index);
                    const cMap = map[cIdx];
                    if (cMap) {
                        if (cMap.recordIndex === mapping.recordIndex && cMap.recordIndex !== undefined) {
                            if (mapping.type === 'field' && cMap.type === 'field' && cMap.fieldName === mapping.fieldName) {
                                c.classList.add("hovered");
                            } 
                            else if (mapping.type === cMap.type && (mapping.type === 'lapide' || mapping.type === 'size')) {
                                c.classList.add("hovered");
                            }
                            else if (mapping.type === 'deleted_data' && cMap.type === 'deleted_data') {
                                c.classList.add("hovered");
                            }
                        } else if (mapping.type === 'header' && cMap.type === 'header') {
                            c.classList.add("hovered");
                        }
                    }
                });
            });

            cell.addEventListener("mousemove", (e) => {
                tooltip.style.left = (e.pageX + 15) + "px";
                tooltip.style.top = (e.pageY + 15) + "px";
            });

            cell.addEventListener("mouseleave", () => {
                tooltip.style.display = "none";
                cells.forEach(c => c.classList.remove("hovered"));
            });
        });
    }

    // Renderização do console de logs
    function renderConsole() {
        consoleBody.innerHTML = "";
        
        if (logPassoAPasso.length === 0) {
            consoleBody.innerHTML = `<div class="console-line system">Console aguardando operações...</div>`;
            return;
        }

        logPassoAPasso.forEach((log, logIdx) => {
            const line = document.createElement("div");
            line.className = "console-line";
            
            if (log.destaque) {
                line.classList.add("action");
            }
            
            line.textContent = `[Fase ${logIdx + 1}] ${log.mensagem}`;

            if (log.offset !== null) {
                line.style.cursor = "pointer";
                line.addEventListener("mouseenter", () => {
                    highlightBytesRange(log.offset, log.bytesCount || 1, true);
                });
                line.addEventListener("mouseleave", () => {
                    highlightBytesRange(log.offset, log.bytesCount || 1, false);
                });
            }

            consoleBody.appendChild(line);
        });

        consoleBody.scrollTop = consoleBody.scrollHeight;
    }

    // Destaca temporariamente um intervalo de bytes
    function highlightBytesRange(start, count, active) {
        const cells = document.querySelectorAll(".byte-cell:not(.empty), .ascii-cell:not(.empty)");
        cells.forEach(cell => {
            const idx = parseInt(cell.dataset.index);
            if (idx >= start && idx < start + count) {
                if (active) {
                    cell.classList.add("hovered");
                } else {
                    cell.classList.remove("hovered");
                }
            }
        });
    }

    // Efeito visual de piscada ao realizar varredura/gravação física
    function flashBytesRange(start, count) {
        const cells = document.querySelectorAll(".byte-cell:not(.empty), .ascii-cell:not(.empty)");
        cells.forEach(cell => {
            const idx = parseInt(cell.dataset.index);
            if (idx >= start && idx < start + count) {
                cell.classList.add("scanned");
                setTimeout(() => {
                    cell.classList.remove("scanned");
                }, 400);
            }
        });
    }

    function flashLastOperationBytes() {
        logPassoAPasso.forEach(log => {
            if (log.offset !== null) {
                flashBytesRange(log.offset, log.bytesCount || 1);
            }
        });
    }

    // Renderização da lista de cursos cadastrados
    function renderCoursesList() {
        const cursosInfo = getAllActiveCourses();
        coursesList.innerHTML = "";

        if (cursosInfo.length === 0) {
            coursesList.innerHTML = `<div class="no-results">Nenhum curso ativo. Vá na barra superior e escolha "Incluir Novo Curso".</div>`;
            return;
        }

        cursosInfo.forEach(info => {
            const c = info.curso;
            
            const div = document.createElement("div");
            div.className = "course-item";
            
            const dataFmt = formatDateBR(c.dataInicio);

            div.innerHTML = `
                <div class="course-info">
                    <div class="course-title-row">
                        <span class="course-title">${c.nome}</span>
                        <span class="course-id-badge">ID: ${c.id}</span>
                        <span class="course-id-badge" style="background-color: #29292e;">Offset: ${info.offset}</span>
                    </div>
                    <div class="course-meta">
                        <span><strong>Início:</strong> ${dataFmt}</span>
                        <span><strong>Código:</strong> ${c.codigo}</span>
                        <span><strong>Estado:</strong> ${c.estado}</span>
                        <span><strong>Usuário:</strong> ${c.idUsuario}</span>
                    </div>
                </div>
                <div class="course-actions">
                    <button class="btn btn-secondary btn-small btn-edit" data-id="${c.id}">Editar</button>
                    <button class="btn btn-danger btn-small btn-delete" data-id="${c.id}">Excluir</button>
                </div>
            `;

            div.querySelector(".btn-edit").addEventListener("click", () => {
                startEditCourse(c.id);
            });

            div.querySelector(".btn-delete").addEventListener("click", () => {
                if (confirm(`Excluir logicamente o curso "${c.nome}" (ID: ${c.id})?`)) {
                    dbDelete(c.id);
                    renderHexViewer();
                    renderConsole();
                    renderCoursesList();
                    flashLastOperationBytes();
                }
            });

            div.addEventListener("mouseenter", () => {
                highlightBytesRange(info.offset, 3 + info.tamanho, true);
            });
            div.addEventListener("mouseleave", () => {
                highlightBytesRange(info.offset, 3 + info.tamanho, false);
            });

            coursesList.appendChild(div);
        });
    }

    // Submissão do formulário de criação/edição
    courseForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const idVal = courseIdInput.value;
        const cursoData = {
            nome: courseNameInput.value.trim(),
            dataInicio: courseDateInput.value,
            estado: parseInt(courseStatusSelect.value),
            idUsuario: parseInt(courseUserIdInput.value),
            descricao: courseDescTextarea.value.trim(),
            codigo: courseShareCodeInput.value || ""
        };

        if (idVal) {
            const id = parseInt(idVal);
            const sucesso = dbUpdate(id, cursoData);
            if (sucesso) {
                resetCourseForm();
                document.querySelector('[data-tab="tab-list"]').click();
                flashLastOperationBytes();
            }
        } else {
            const novoCurso = dbCreate(cursoData);
            if (novoCurso) {
                resetCourseForm();
                document.querySelector('[data-tab="tab-list"]').click();
                flashLastOperationBytes();
            }
        }

        renderHexViewer();
        renderConsole();
    });

    // Carrega dados de um curso no formulário para edição
    function startEditCourse(id) {
        const resultado = dbRead(id);
        if (resultado) {
            const c = resultado.curso;
            
            courseIdInput.value = c.id;
            courseNameInput.value = c.nome;
            courseDateInput.value = c.dataInicio;
            courseStatusSelect.value = c.estado;
            courseUserIdInput.value = c.idUsuario;
            courseShareCodeInput.value = c.codigo;
            courseDescTextarea.value = c.descricao;

            formTitle.textContent = `Alterar Curso ID #${c.id}`;
            btnSubmitCourse.textContent = "Gravar Alterações";
            btnCancelEdit.classList.remove("hidden");

            document.querySelector('[data-tab="tab-insert"]').click();

            renderConsole();
            flashLastOperationBytes();
        }
    }

    function resetCourseForm() {
        courseIdInput.value = "";
        courseForm.reset();
        courseShareCodeInput.value = "";
        courseUserIdInput.value = "1";
        
        formTitle.textContent = "Incluir Novo Curso";
        btnSubmitCourse.textContent = "Salvar";
        btnCancelEdit.classList.add("hidden");
    }

    btnCancelEdit.addEventListener("click", () => {
        resetCourseForm();
        document.querySelector('[data-tab="tab-list"]').click();
    });

    // Renderiza o resultado da busca
    function renderSearchResult(resultado) {
        searchResults.innerHTML = "";
        
        if (!resultado) {
            searchResults.innerHTML = `<div class="no-results" style="border-color: #c62828; color: #e57373;">Curso não encontrado.</div>`;
            return;
        }

        const c = resultado.curso;
        const dataFmt = formatDateBR(c.dataInicio);
        const estadoNomes = ["Ativo e com inscrições", "Ativo sem inscrições", "Concluído", "Cancelado"];

        const div = document.createElement("div");
        div.className = "course-item";
        div.style.borderColor = "#2e7d32";
        div.innerHTML = `
            <div class="course-info">
                <div class="course-title-row">
                    <span class="course-title" style="color: #81c784;">${c.nome}</span>
                    <span class="course-id-badge">ID: ${c.id}</span>
                    <span class="course-id-badge" style="background-color: #29292e;">Offset Físico: ${resultado.offset}</span>
                </div>
                <div class="course-meta">
                    <span><strong>Início:</strong> ${dataFmt}</span>
                    <span><strong>Código:</strong> ${c.codigo}</span>
                    <span><strong>Estado:</strong> ${c.estado} - ${estadoNomes[c.estado]}</span>
                    <span><strong>Dono:</strong> ${c.idUsuario}</span>
                </div>
                <div style="font-size: 12px; color: #a8a8b3; margin-top: 5px; border-top: 1px solid #29292e; padding-top: 4px;">
                    ${c.descricao}
                </div>
            </div>
            <div class="course-actions">
                <button class="btn btn-secondary btn-small btn-edit" data-id="${c.id}">Editar</button>
                <button class="btn btn-danger btn-small btn-delete" data-id="${c.id}">Excluir</button>
            </div>
        `;

        div.querySelector(".btn-edit").addEventListener("click", () => {
            startEditCourse(c.id);
        });

        div.querySelector(".btn-delete").addEventListener("click", () => {
            if (confirm(`Excluir logicamente o curso "${c.nome}" (ID: ${c.id})?`)) {
                dbDelete(c.id);
                renderHexViewer();
                renderConsole();
                resetCourseForm();
                searchResults.innerHTML = `<div class="no-results">Curso ID ${c.id} foi excluído.</div>`;
            }
        });

        div.addEventListener("mouseenter", () => {
            highlightBytesRange(resultado.offset, 3 + resultado.tamanho, true);
        });
        div.addEventListener("mouseleave", () => {
            highlightBytesRange(resultado.offset, 3 + resultado.tamanho, false);
        });

        searchResults.appendChild(div);
        flashBytesRange(resultado.offset, 3 + resultado.tamanho);
    }

    btnSearchId.addEventListener("click", () => {
        const idVal = searchIdInput.value.trim();
        if (!idVal) {
            alert("Insira o ID!");
            return;
        }

        const id = parseInt(idVal);
        const resultado = dbRead(id);
        
        renderConsole();
        renderHexViewer();
        renderSearchResult(resultado);
    });

    btnSearchName.addEventListener("click", () => {
        const nameVal = searchNameInput.value.trim();
        if (!nameVal) {
            alert("Insira o termo!");
            return;
        }

        const resultadosBusca = dbReadByName(nameVal);
        
        renderConsole();
        renderHexViewer();

        searchResults.innerHTML = "";
        if (resultadosBusca.length > 0) {
            resultadosBusca.forEach(resultado => {
                const c = resultado.curso;
                const dataFmt = formatDateBR(c.dataInicio);

                const div = document.createElement("div");
                div.className = "course-item";
                div.style.borderColor = "#4f46e5";
                div.style.marginBottom = "8px";
                div.innerHTML = `
                    <div class="course-info">
                        <div class="course-title-row">
                            <span class="course-title">${c.nome}</span>
                            <span class="course-id-badge">ID: ${c.id}</span>
                            <span class="course-id-badge" style="background-color: #29292e;">Offset: ${resultado.offset}</span>
                        </div>
                        <div class="course-meta">
                            <span><strong>Início:</strong> ${dataFmt}</span>
                            <span><strong>Código:</strong> ${c.codigo}</span>
                            <span><strong>Estado:</strong> ${c.estado}</span>
                        </div>
                    </div>
                    <div class="course-actions">
                        <button class="btn btn-secondary btn-small btn-edit" data-id="${c.id}">Editar</button>
                        <button class="btn btn-danger btn-small btn-delete" data-id="${c.id}">Excluir</button>
                    </div>
                `;

                div.querySelector(".btn-edit").addEventListener("click", () => {
                    startEditCourse(c.id);
                });

                div.querySelector(".btn-delete").addEventListener("click", () => {
                    if (confirm(`Excluir logicamente o curso "${c.nome}" (ID: ${c.id})?`)) {
                        dbDelete(c.id);
                        renderHexViewer();
                        renderConsole();
                        resetCourseForm();
                        btnSearchName.click();
                    }
                });

                div.addEventListener("mouseenter", () => {
                    highlightBytesRange(resultado.offset, 3 + resultado.tamanho, true);
                });
                div.addEventListener("mouseleave", () => {
                    highlightBytesRange(resultado.offset, 3 + resultado.tamanho, false);
                });

                searchResults.appendChild(div);
                flashBytesRange(resultado.offset, 3 + resultado.tamanho);
            });
        } else {
            searchResults.innerHTML = `<div class="no-results">Nenhum curso correspondente ao termo "${nameVal}".</div>`;
        }
    });

    btnClearConsole.addEventListener("click", () => {
        clearLog();
    });

    btnResetDB.addEventListener("click", () => {
        if (confirm("Apagar todas as alterações e recarregar cursos padrão?")) {
            initializeDatabase(true);
            renderHexViewer();
            renderConsole();
            renderCoursesList();
            resetCourseForm();
            searchResults.innerHTML = `<div class="no-results">Aguardando critérios de busca...</div>`;
        }
    });

    // Atualização reativa da tela com base nos eventos do banco de dados
    onEvent('dbUpdated', () => {
        renderHexViewer();
    });

    onEvent('logUpdated', () => {
        renderConsole();
    });

    // Inicialização da interface
    renderHexViewer();
    renderConsole();
    renderCoursesList();
});
