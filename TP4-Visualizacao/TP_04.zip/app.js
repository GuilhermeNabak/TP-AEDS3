// Motor de Banco de Dados Físico em LocalStorage com serialização compatível com Java (AEDS III)

const DB_KEY = "TP4_AEDS3_DATABASE";

const encoder = new TextEncoder();
const decoder = new TextDecoder("utf-8");

let logPassoAPasso = [];

function clearLog() {
    logPassoAPasso = [];
    triggerEvent('logUpdated');
}

function addLog(mensagem, destaque = false, offset = null, bytesCount = null) {
    logPassoAPasso.push({ mensagem, destaque, offset, bytesCount });
    triggerEvent('logUpdated');
}

// Emissor de eventos simples para reatividade da UI
const listeners = {};
function onEvent(event, callback) {
    if (!listeners[event]) listeners[event] = [];
    listeners[event].push(callback);
}
function triggerEvent(event, data) {
    if (listeners[event]) {
        listeners[event].forEach(cb => cb(data));
    }
}

// Funções de leitura e escrita de inteiros e shorts (Big Endian)
function writeInt(value, array, offset) {
    array[offset] = (value >> 24) & 0xFF;
    array[offset + 1] = (value >> 16) & 0xFF;
    array[offset + 2] = (value >> 8) & 0xFF;
    array[offset + 3] = value & 0xFF;
}

function readInt(array, offset) {
    return (array[offset] << 24) |
           (array[offset + 1] << 16) |
           (array[offset + 2] << 8) |
           array[offset + 3];
}

function writeShort(value, array, offset) {
    array[offset] = (value >> 8) & 0xFF;
    array[offset + 1] = value & 0xFF;
}

function readShort(array, offset) {
    return (array[offset] << 8) | array[offset + 1];
}

// Conversão de data para dias decorridos desde a época do Java (1970-01-01)
function dateToEpochDay(dateStr) {
    if (!dateStr) return 0;
    const ms = Date.parse(dateStr + "T00:00:00Z");
    if (isNaN(ms)) return 0;
    return Math.floor(ms / (1000 * 60 * 60 * 24));
}

function epochDayToDate(epochDay) {
    const ms = epochDay * 24 * 60 * 60 * 1000;
    const d = new Date(ms);
    return d.toISOString().split('T')[0];
}

function formatDateBR(dateStr) {
    if (!dateStr) return "";
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

// NanoID simplificado de 10 caracteres para código compartilhável
function generateNanoID() {
    const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
    let id = "";
    for (let i = 0; i < 10; i++) {
        id += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
    }
    return id;
}

// Persistência física no LocalStorage
function getDatabaseBytes() {
    const dbStr = localStorage.getItem(DB_KEY);
    if (!dbStr) return [];
    try {
        return JSON.parse(dbStr);
    } catch (e) {
        console.error("Erro ao ler do LocalStorage, reiniciando...", e);
        return [];
    }
}

function saveDatabaseBytes(bytes) {
    localStorage.setItem(DB_KEY, JSON.stringify(bytes));
    triggerEvent('dbUpdated');
}

// Serializa registro de Curso seguindo o layout binário
function serializeCurso(curso) {
    const bytes = [];

    // 1. ID (4 bytes, int)
    const idBytes = new Array(4);
    writeInt(curso.id, idBytes, 0);
    bytes.push(...idBytes);

    // 2. Nome (2 bytes tamanho + caracteres UTF-8)
    const nomeBytes = encoder.encode(curso.nome);
    const nomeLenBytes = new Array(2);
    writeShort(nomeBytes.length, nomeLenBytes, 0);
    bytes.push(...nomeLenBytes, ...nomeBytes);

    // 3. Data de início (4 bytes, int epoch day)
    const dateBytes = new Array(4);
    writeInt(dateToEpochDay(curso.dataInicio), dateBytes, 0);
    bytes.push(...dateBytes);

    // 4. Descrição (2 bytes tamanho + caracteres UTF-8)
    const descBytes = encoder.encode(curso.descricao);
    const descLenBytes = new Array(2);
    writeShort(descBytes.length, descLenBytes, 0);
    bytes.push(...descLenBytes, ...descBytes);

    // 5. Código compartilhável (2 bytes tamanho + caracteres UTF-8)
    const codBytes = encoder.encode(curso.codigo);
    const codLenBytes = new Array(2);
    writeShort(codBytes.length, codLenBytes, 0);
    bytes.push(...codLenBytes, ...codBytes);

    // 6. Estado (4 bytes, int)
    const estBytes = new Array(4);
    writeInt(curso.estado, estBytes, 0);
    bytes.push(...estBytes);

    // 7. ID do Usuário (4 bytes, int)
    const usrBytes = new Array(4);
    writeInt(curso.idUsuario, usrBytes, 0);
    bytes.push(...usrBytes);

    return bytes;
}

// Deserializa os bytes a partir do offset
function deserializeCurso(bytes, offset) {
    let current = offset;

    const id = readInt(bytes, current);
    current += 4;

    const nomeLen = readShort(bytes, current);
    current += 2;
    const nomeBytes = bytes.slice(current, current + nomeLen);
    const nome = decoder.decode(new Uint8Array(nomeBytes));
    current += nomeLen;

    const epochDay = readInt(bytes, current);
    const dataInicio = epochDayToDate(epochDay);
    current += 4;

    const descLen = readShort(bytes, current);
    current += 2;
    const descBytes = bytes.slice(current, current + descLen);
    const descricao = decoder.decode(new Uint8Array(descBytes));
    current += descLen;

    const codLen = readShort(bytes, current);
    current += 2;
    const codBytes = bytes.slice(current, current + codLen);
    const codigo = decoder.decode(new Uint8Array(codBytes));
    current += codLen;

    const estado = readInt(bytes, current);
    current += 4;

    const idUsuario = readInt(bytes, current);
    current += 4;

    return {
        curso: { id, nome, dataInicio, descricao, codigo, estado, idUsuario },
        bytesRead: current - offset
    };
}

// Cria o arquivo de dados com o cabeçalho (4 bytes para o último ID inserido)
function initializeDatabase(forced = false) {
    const bytes = getDatabaseBytes();
    if (bytes.length === 0 || forced) {
        clearLog();
        addLog("Inicializando o arquivo de dados com cabeçalho de 4 bytes...", true, 0, 4);
        
        const header = new Array(4).fill(0);
        writeInt(0, header, 0);

        saveDatabaseBytes(header);
        addLog("Arquivo de dados inicializado com sucesso contendo ultimoID = 0.", false);
    }
}

// CREATE (Incluir Novo Curso no arquivo)
function dbCreate(cursoInput) {
    clearLog();
    addLog("=== INICIANDO OPERAÇÃO: INCLUIR REGISTRO ===", true);

    const bytes = getDatabaseBytes();
    if (bytes.length < 4) {
        initializeDatabase(true);
        return dbCreate(cursoInput);
    }

    // Obtém e atualiza o ultimoID no cabeçalho
    addLog("Buscando último ID cadastrado no cabeçalho (offset 0 a 3)...", false, 0, 4);
    const ultimoID = readInt(bytes, 0);
    const novoID = ultimoID + 1;
    addLog(`Último ID lido: ${ultimoID}. Novo ID gerado: ${novoID}.`, false);

    writeInt(novoID, bytes, 0);
    addLog(`Escrevendo novo ID ${novoID} de volta no cabeçalho (offset 0 a 3)...`, false, 0, 4);

    const curso = {
        ...cursoInput,
        id: novoID,
        codigo: generateNanoID()
    };

    const cursoBytes = serializeCurso(curso);
    const registroTam = cursoBytes.length;
    addLog(`Serializando dados do curso. Tamanho do vetor de bytes: ${registroTam} bytes.`, false);

    // Busca espaço livre em registros excluídos (lápide '*' e tamanho suficiente)
    let index = 4;
    let enderecoDestino = -1;

    addLog("Procurando espaço livre (lápides marcadas como excluídas '*') para reuso...", false);
    while (index < bytes.length) {
        const lapide = bytes[index];
        const tam = readShort(bytes, index + 1);

        if (lapide === 0x2A) { // Lápide '*' indica registro logicamente excluído
            addLog(`Registro excluído encontrado no offset ${index} de tamanho ${tam} bytes.`, false, index, 3);
            if (tam >= registroTam) {
                enderecoDestino = index;
                addLog(`Espaço reutilizável adequado de ${tam} bytes encontrado no offset ${index}! (Requerido: ${registroTam} bytes)`, true, index, 3 + tam);
                break;
            } else {
                addLog(`Espaço de ${tam} bytes no offset ${index} é muito pequeno. Continuando busca...`, false);
            }
        }
        index += 3 + tam;
    }

    if (enderecoDestino === -1) {
        // Gravação no final do arquivo por falta de espaço reutilizável
        enderecoDestino = bytes.length;
        addLog(`Nenhum espaço excluído compatível encontrado. Gravando no final do arquivo (offset ${enderecoDestino}).`, false);
        
        bytes.push(0x20); // Lápide ativo ' '
        const sizeBytes = new Array(2);
        writeShort(registroTam, sizeBytes, 0);
        bytes.push(...sizeBytes);
        bytes.push(...cursoBytes);

        addLog(`Registro gravado no final do arquivo: Lápide ' ' (1 byte) + Tamanho ${registroTam} (2 bytes) + Dados (${registroTam} bytes).`, true, enderecoDestino, 3 + registroTam);
    } else {
        // Sobrescrita do registro excluído
        bytes[enderecoDestino] = 0x20; // Altera lápide para ativo ' '
        addLog(`Reutilizando espaço: limpando lápide para ' ' no offset ${enderecoDestino} e escrevendo os bytes...`, false, enderecoDestino, 1);
        
        const tamDisponivel = readShort(bytes, enderecoDestino + 1);
        for (let i = 0; i < registroTam; i++) {
            bytes[enderecoDestino + 3 + i] = cursoBytes[i];
        }
        
        // Limpa o espaço residual se o novo registro for menor que o espaço disponível
        if (registroTam < tamDisponivel) {
            for (let i = registroTam; i < tamDisponivel; i++) {
                bytes[enderecoDestino + 3 + i] = 0x00;
            }
            const bytesLixo = tamDisponivel - registroTam;
            addLog(`Aviso: O novo registro é menor que o espaço disponível. Sobrando ${bytesLixo} bytes de lixo residual que serão zerados (0x00).`, false);
        }
        addLog(`Registro gravado sobre o espaço excluído no offset ${enderecoDestino}.`, true, enderecoDestino, 3 + tamDisponivel);
    }

    saveDatabaseBytes(bytes);
    addLog(`=== OPERAÇÃO CONCLUÍDA: Curso "${curso.nome}" inserido com sucesso (ID: ${curso.id})! ===`, true);
    return curso;
}

// READ (Buscar Curso por ID)
function dbRead(id) {
    clearLog();
    addLog(`=== INICIANDO OPERAÇÃO: BUSCAR CURSO (ID: ${id}) ===`, true);

    const bytes = getDatabaseBytes();
    let index = 4;

    addLog("Lendo o cabeçalho (ID máximo)...", false, 0, 4);

    while (index < bytes.length) {
        const lapide = bytes[index];
        const tam = readShort(bytes, index + 1);
        const offsetDados = index + 3;

        addLog(`Verificando registro no offset ${index}. Lápide: '${String.fromCharCode(lapide)}' (0x${lapide.toString(16).toUpperCase()}), Tamanho: ${tam} bytes.`, false, index, 3);

        if (lapide === 0x20) { // Registro ativo
            const idRegistro = readInt(bytes, offsetDados);
            addLog(`Registro ativo encontrado. Lendo ID no offset ${offsetDados}... ID Lido: ${idRegistro}.`, false, offsetDados, 4);

            if (idRegistro === id) {
                addLog(`Sucesso! Registro com ID ${id} encontrado no offset ${index}. Deserializando registro completo...`, true, index, 3 + tam);
                const { curso } = deserializeCurso(bytes, offsetDados);
                addLog(`Curso encontrado: "${curso.nome}".`, false);
                return { curso, offset: index, tamanho: tam };
            } else {
                addLog(`ID ${idRegistro} não corresponde ao ID buscado (${id}). Avançando ${tam} bytes.`, false);
            }
        } else {
            addLog(`Registro no offset ${index} está deletado (lápide '*'). Saltando ${tam} bytes de dados.`, false);
        }

        index += 3 + tam;
    }

    addLog(`Fim do arquivo alcançado. Registro com ID ${id} não foi encontrado.`, true);
    return null;
}

// READ (Buscar por Nome - Busca Sequencial)
function dbReadByName(nomeBusca) {
    clearLog();
    addLog(`=== INICIANDO OPERAÇÃO: BUSCAR POR NOME ("${nomeBusca}") ===`, true);

    const bytes = getDatabaseBytes();
    let index = 4;
    const resultados = [];
    const termo = nomeBusca.toLowerCase().trim();

    addLog("Iniciando varredura linear do arquivo...", false);

    while (index < bytes.length) {
        const lapide = bytes[index];
        const tam = readShort(bytes, index + 1);
        const offsetDados = index + 3;

        if (lapide === 0x20) {
            const { curso } = deserializeCurso(bytes, offsetDados);
            addLog(`Verificando registro ativo ID ${curso.id}: "${curso.nome}"...`, false, index, 3 + tam);
            
            if (curso.nome.toLowerCase().includes(termo)) {
                addLog(`Correspondência encontrada! Adicionando ID ${curso.id} aos resultados.`, true, index, 3 + tam);
                resultados.push({ curso, offset: index, tamanho: tam });
            }
        } else {
            addLog(`Saltando registro excluído no offset ${index}...`, false, index, 3);
        }
        index += 3 + tam;
    }

    addLog(`Busca concluída. ${resultados.length} resultados encontrados.`, true);
    return resultados;
}

// UPDATE (Alterar Registro)
function dbUpdate(id, cursoAlterado) {
    clearLog();
    addLog(`=== INICIANDO OPERAÇÃO: ALTERAR CURSO (ID: ${id}) ===`, true);

    const bytes = getDatabaseBytes();
    let index = 4;
    let encontrado = false;

    while (index < bytes.length) {
        const lapide = bytes[index];
        const tam = readShort(bytes, index + 1);
        const offsetDados = index + 3;

        if (lapide === 0x20) {
            const idRegistro = readInt(bytes, offsetDados);
            if (idRegistro === id) {
                encontrado = true;
                addLog(`Registro a ser alterado encontrado no offset ${index}. Tamanho atual em disco: ${tam} bytes.`, true, index, 3);

                const { curso: cursoOriginal } = deserializeCurso(bytes, offsetDados);
                const cursoFinal = {
                    ...cursoAlterado,
                    id: id,
                    codigo: cursoOriginal.codigo
                };

                const novosBytes = serializeCurso(cursoFinal);
                const novoTamanho = novosBytes.length;
                addLog(`Tamanho dos dados atualizados serializados: ${novoTamanho} bytes.`, false);

                // Caso 1: Registro atualizado cabe no espaço em disco existente (sobrescrita in-place)
                if (novoTamanho <= tam) {
                    addLog(`Ótimo! Novo tamanho (${novoTamanho} bytes) cabe no espaço atual (${tam} bytes). Sobrescrita in-place!`, true);
                    
                    for (let i = 0; i < novoTamanho; i++) {
                        bytes[offsetDados + i] = novosBytes[i];
                    }
                    
                    if (novoTamanho < tam) {
                        for (let i = novoTamanho; i < tam; i++) {
                            bytes[offsetDados + i] = 0x00;
                        }
                        addLog(`Limpando ${tam - novoTamanho} bytes sobressalentes antigos com zero (0x00).`, false);
                    }
                    
                    addLog(`Dados atualizados gravados com sucesso na mesma posição!`, true, index, 3 + tam);
                } 
                // Caso 2: Registro atualizado é maior que o espaço disponível (exclui antigo e move registro)
                else {
                    addLog(`Atenção: Novo tamanho (${novoTamanho} bytes) excede o espaço atual (${tam} bytes). O registro precisa ser movido!`, true);
                    
                    // Marca o registro anterior como excluído
                    bytes[index] = 0x2A; // '*'
                    addLog(`Marcando registro antigo no offset ${index} como excluído (Lápide '*').`, false, index, 1);

                    // Busca outra lacuna excluída que comporte o novo tamanho, ou anexa ao final
                    let indexBusca = 4;
                    let enderecoReuso = -1;

                    addLog("Procurando outro registro deletado que comporte o novo tamanho...", false);
                    while (indexBusca < bytes.length) {
                        const lapideBusca = bytes[indexBusca];
                        const tamBusca = readShort(bytes, indexBusca + 1);

                        if (lapideBusca === 0x2A && indexBusca !== index) {
                            if (tamBusca >= novoTamanho) {
                                enderecoReuso = indexBusca;
                                addLog(`Espaço livre adequado encontrado no offset ${enderecoReuso} (Tamanho: ${tamBusca} bytes).`, true, enderecoReuso, 3);
                                break;
                            }
                        }
                        indexBusca += 3 + tamBusca;
                    }

                    if (enderecoReuso === -1) {
                        const novoEndereco = bytes.length;
                        addLog(`Nenhum espaço livre suficiente. Gravando dados atualizados no final do arquivo (offset ${novoEndereco}).`, false);
                        
                        bytes.push(0x20); // Lápide ativo ' '
                        const sizeBytes = new Array(2);
                        writeShort(novoTamanho, sizeBytes, 0);
                        bytes.push(...sizeBytes);
                        bytes.push(...novosBytes);

                        addLog(`Registro atualizado anexado no final do arquivo.`, true, novoEndereco, 3 + novoTamanho);
                    } else {
                        bytes[enderecoReuso] = 0x20;
                        addLog(`Reutilizando espaço livre no offset ${enderecoReuso}. Limpando lápide para ' '...`, false, enderecoReuso, 1);
                        
                        const tamDisponivel = readShort(bytes, enderecoReuso + 1);
                        for (let i = 0; i < novoTamanho; i++) {
                            bytes[enderecoReuso + 3 + i] = novosBytes[i];
                        }
                        if (novoTamanho < tamDisponivel) {
                            for (let i = novoTamanho; i < tamDisponivel; i++) {
                                bytes[enderecoReuso + 3 + i] = 0x00;
                            }
                        }
                        addLog(`Registro atualizado gravado no offset ${enderecoReuso}.`, true, enderecoReuso, 3 + tamDisponivel);
                    }
                }
                break;
            }
        }
        index += 3 + tam;
    }

    if (!encontrado) {
        addLog(`Erro: Curso com ID ${id} não foi encontrado para atualização.`, true);
        return false;
    }

    saveDatabaseBytes(bytes);
    addLog(`=== OPERAÇÃO CONCLUÍDA: Curso ID ${id} atualizado com sucesso! ===`, true);
    return true;
}

// DELETE (Exclusão Lógica escrevendo '*' na lápide)
function dbDelete(id) {
    clearLog();
    addLog(`=== INICIANDO OPERAÇÃO: EXCLUIR CURSO (ID: ${id}) ===`, true);

    const bytes = getDatabaseBytes();
    let index = 4;
    let deletado = false;

    while (index < bytes.length) {
        const lapide = bytes[index];
        const tam = readShort(bytes, index + 1);
        const offsetDados = index + 3;

        if (lapide === 0x20) {
            const idRegistro = readInt(bytes, offsetDados);
            if (idRegistro === id) {
                deletado = true;
                addLog(`Registro encontrado no offset ${index}. Gravando '*' na lápide (offset ${index}) para marcar exclusão lógica...`, true, index, 1);
                
                bytes[index] = 0x2A; // '*' indica deletado logicamente

                addLog(`Exclusão lógica realizada com sucesso. O espaço de ${tam} bytes de dados permanece fisicamente no arquivo, disponível para reuso futuro.`, false, index, 3 + tam);
                break;
            }
        }
        index += 3 + tam;
    }

    if (!deletado) {
        addLog(`Erro: Curso com ID ${id} não foi encontrado para exclusão.`, true);
        return false;
    }

    saveDatabaseBytes(bytes);
    addLog(`=== OPERAÇÃO CONCLUÍDA: Curso ID ${id} excluído logicamente! ===`, true);
    return true;
}

// Retorna todos os cursos ativos no banco
function getAllActiveCourses() {
    const bytes = getDatabaseBytes();
    const cursosAtivos = [];
    let index = 4;

    while (index < bytes.length) {
        const lapide = bytes[index];
        const tam = readShort(bytes, index + 1);
        const offsetDados = index + 3;

        if (lapide === 0x20) {
            try {
                const { curso } = deserializeCurso(bytes, offsetDados);
                cursosAtivos.push({ curso, offset: index, tamanho: tam });
            } catch (e) {
                console.error("Erro ao deserializar curso no offset " + offsetDados, e);
            }
        }
        index += 3 + tam;
    }
    return cursosAtivos;
}

// Gera o mapeamento lógico e descrições detalhadas dos bytes do arquivo para a UI
function mapDatabaseBytes() {
    const bytes = getDatabaseBytes();
    const map = new Array(bytes.length);

    if (bytes.length === 0) return [];

    // Cabeçalho: 4 bytes do ID máximo
    const ultimoID = bytes.length >= 4 ? readInt(bytes, 0) : 0;
    for (let i = 0; i < Math.min(4, bytes.length); i++) {
        map[i] = {
            offset: i,
            value: bytes[i],
            type: 'header',
            fieldName: 'ultimoID',
            desc: `Cabeçalho: último ID gravado (Valor atual: ${ultimoID})`
        };
    }

    let index = 4;
    let recordIndex = 0;

    while (index < bytes.length) {
        const lapideOffset = index;
        const sizeOffset = index + 1;
        const dataOffset = index + 3;

        const lapide = bytes[lapideOffset];
        if (lapide === undefined) break;

        const tam = bytes.length >= sizeOffset + 2 ? readShort(bytes, sizeOffset) : 0;

        // Lápide (1 byte)
        map[lapideOffset] = {
            offset: lapideOffset,
            value: lapide,
            type: 'lapide',
            recordIndex,
            desc: `Registro #${recordIndex + 1}: Lápide ('${String.fromCharCode(lapide)}' - ${lapide === 0x20 ? 'Ativo' : 'Excluído'})`
        };

        // Tamanho (2 bytes)
        for (let i = 0; i < 2; i++) {
            const off = sizeOffset + i;
            if (off < bytes.length) {
                map[off] = {
                    offset: off,
                    value: bytes[off],
                    type: 'size',
                    recordIndex,
                    desc: `Registro #${recordIndex + 1}: Indicador de tamanho do registro (${tam} bytes de dados)`
                };
            }
        }

        // Mapeamento detalhado dos campos de dados do registro ativo
        if (lapide === 0x20) {
            let curr = dataOffset;

            // ID do Curso (4 bytes)
            if (curr + 4 <= bytes.length) {
                const idVal = readInt(bytes, curr);
                for (let i = 0; i < 4; i++) {
                    map[curr + i] = {
                        offset: curr + i,
                        value: bytes[curr + i],
                        type: 'field',
                        fieldName: 'id',
                        recordIndex,
                        desc: `Registro #${recordIndex + 1} - Campo ID (Valor: ${idVal})`
                    };
                }
                curr += 4;
            }

            // Nome (2 bytes len + chars)
            if (curr + 2 <= bytes.length) {
                const nomeLen = readShort(bytes, curr);
                map[curr] = {
                    offset: curr, value: bytes[curr], type: 'field', fieldName: 'nome_len', recordIndex,
                    desc: `Registro #${recordIndex + 1} - Tamanho do Nome (${nomeLen} bytes)`
                };
                map[curr + 1] = {
                    offset: curr + 1, value: bytes[curr + 1], type: 'field', fieldName: 'nome_len', recordIndex,
                    desc: `Registro #${recordIndex + 1} - Tamanho do Nome (${nomeLen} bytes)`
                };
                curr += 2;

                const nomeEnd = Math.min(curr + nomeLen, bytes.length);
                const nomeSlice = bytes.slice(curr, nomeEnd);
                const nomeVal = decoder.decode(new Uint8Array(nomeSlice));

                for (let i = curr; i < nomeEnd; i++) {
                    map[i] = {
                        offset: i,
                        value: bytes[i],
                        type: 'field',
                        fieldName: 'nome',
                        recordIndex,
                        desc: `Registro #${recordIndex + 1} - Campo Nome: letra '${String.fromCharCode(bytes[i])}' (Nome completo: "${nomeVal}")`
                    };
                }
                curr = nomeEnd;
            }

            // Data Início (4 bytes)
            if (curr + 4 <= bytes.length) {
                const epoch = readInt(bytes, curr);
                const dateVal = epochDayToDate(epoch);
                for (let i = 0; i < 4; i++) {
                    map[curr + i] = {
                        offset: curr + i,
                        value: bytes[curr + i],
                        type: 'field',
                        fieldName: 'dataInicio',
                        recordIndex,
                        desc: `Registro #${recordIndex + 1} - Campo Data Início: ${formatDateBR(dateVal)} (Epoch Day: ${epoch})`
                    };
                }
                curr += 4;
            }

            // Descrição (2 bytes len + chars)
            if (curr + 2 <= bytes.length) {
                const descLen = readShort(bytes, curr);
                map[curr] = {
                    offset: curr, value: bytes[curr], type: 'field', fieldName: 'descricao_len', recordIndex,
                    desc: `Registro #${recordIndex + 1} - Tamanho da Descrição (${descLen} bytes)`
                };
                map[curr + 1] = {
                    offset: curr + 1, value: bytes[curr + 1], type: 'field', fieldName: 'descricao_len', recordIndex,
                    desc: `Registro #${recordIndex + 1} - Tamanho da Descrição (${descLen} bytes)`
                };
                curr += 2;

                const descEnd = Math.min(curr + descLen, bytes.length);
                const descSlice = bytes.slice(curr, descEnd);
                const descVal = decoder.decode(new Uint8Array(descSlice));

                for (let i = curr; i < descEnd; i++) {
                    map[i] = {
                        offset: i,
                        value: bytes[i],
                        type: 'field',
                        fieldName: 'descricao',
                        recordIndex,
                        desc: `Registro #${recordIndex + 1} - Campo Descrição (Texto: "${descVal.substring(0, 15)}...")`
                    };
                }
                curr = descEnd;
            }

            // Código compartilhável (2 bytes len + chars)
            if (curr + 2 <= bytes.length) {
                const codLen = readShort(bytes, curr);
                map[curr] = {
                    offset: curr, value: bytes[curr], type: 'field', fieldName: 'codigo_len', recordIndex,
                    desc: `Registro #${recordIndex + 1} - Tamanho do Código (${codLen} bytes)`
                };
                map[curr + 1] = {
                    offset: curr + 1, value: bytes[curr + 1], type: 'field', fieldName: 'codigo_len', recordIndex,
                    desc: `Registro #${recordIndex + 1} - Tamanho do Código (${codLen} bytes)`
                };
                curr += 2;

                const codEnd = Math.min(curr + codLen, bytes.length);
                const codSlice = bytes.slice(curr, codEnd);
                const codVal = decoder.decode(new Uint8Array(codSlice));

                for (let i = curr; i < codEnd; i++) {
                    map[i] = {
                        offset: i,
                        value: bytes[i],
                        type: 'field',
                        fieldName: 'codigo',
                        recordIndex,
                        desc: `Registro #${recordIndex + 1} - Campo Código Compartilhável: '${String.fromCharCode(bytes[i])}' (Código completo: "${codVal}")`
                    };
                }
                curr = codEnd;
            }

            // Estado (4 bytes)
            if (curr + 4 <= bytes.length) {
                const estVal = readInt(bytes, curr);
                const estNomes = ["Ativo e recebendo inscrições", "Ativo, sem novas inscrições", "Realizado e concluído", "Cancelado"];
                for (let i = 0; i < 4; i++) {
                    map[curr + i] = {
                        offset: curr + i,
                        value: bytes[curr + i],
                        type: 'field',
                        fieldName: 'estado',
                        recordIndex,
                        desc: `Registro #${recordIndex + 1} - Campo Estado (Valor: ${estVal} - ${estNomes[estVal] || 'Desconhecido'})`
                    };
                }
                curr += 4;
            }

            // ID do Usuário (4 bytes)
            if (curr + 4 <= bytes.length) {
                const usrVal = readInt(bytes, curr);
                for (let i = 0; i < 4; i++) {
                    map[curr + i] = {
                        offset: curr + i,
                        value: bytes[curr + i],
                        type: 'field',
                        fieldName: 'idUsuario',
                        recordIndex,
                        desc: `Registro #${recordIndex + 1} - ID do Usuário criador (Valor: ${usrVal})`
                    };
                }
                curr += 4;
            }

            // Bytes residuais/lixo de tamanho sobressalente
            while (curr < dataOffset + tam && curr < bytes.length) {
                map[curr] = {
                    offset: curr,
                    value: bytes[curr],
                    type: 'field',
                    fieldName: 'residual',
                    recordIndex,
                    desc: `Registro #${recordIndex + 1} - Byte residual antigo (lixo físico ignorado)`
                };
                curr++;
            }

        } else {
            // Mapeia toda a área de dados excluídos
            for (let i = 0; i < tam; i++) {
                const off = dataOffset + i;
                if (off < bytes.length) {
                    map[off] = {
                        offset: off,
                        value: bytes[off],
                        type: 'deleted_data',
                        recordIndex,
                        desc: `Registro #${recordIndex + 1}: Dados excluídos logicamente (Valor físico: 0x${bytes[off].toString(16).toUpperCase()})`
                    };
                }
            }
        }

        index += 3 + tam;
        recordIndex++;
    }

    return map;
}
