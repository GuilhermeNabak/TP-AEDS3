package Views;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import Entidades.Curso;
import Menus.ConsoleUtils;

public class VisaoCurso {

    private static Scanner console = new Scanner(System.in);
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    public String mostraMenuPrincipalCursos(List<Curso> cursos) {
        ConsoleUtils.limparTela();

        System.out.println("\n\nEntrePares");
        System.out.println("-----------------");
        System.out.println("> Início > Meus cursos");
        System.out.println("\nCURSOS");
        if (cursos.isEmpty()) {
            System.out.println("Nenhum curso cadastrado.");
        } else {
            for (int i = 0; i < cursos.size(); i++) {
                Curso c = cursos.get(i);
                System.out.printf("(%d) %s - %s\n", i + 1, c.getNome(), c.getDataInicioFormatada());
            }
        }
        System.out.println("\n(N) Novo curso");
        System.out.println("(R) Retornar ao menu anterior");
        System.out.print("\nOpção: ");
        return console.nextLine().trim().toUpperCase();
    }

    public char mostraMenuDetalheCurso(Curso c) {
        ConsoleUtils.limparTela();

        System.out.println("EntrePares");
        System.out.println("-----------------");
        System.out.println("> Início > Meus cursos > " + c.getNome());
        System.out.println("\nCÓDIGO......: " + c.getCodigoCompartilhavel());
        System.out.println("NOME........: " + c.getNome());
        System.out.println("DESCRIÇÃO...: " + c.getDescricao());
        System.out.println("DATA DE INICIO: " + c.getDataInicioFormatada());
        System.out.println("\n" + c.getEstadoDescricao());

        System.out.println("\n(A) Gerenciar inscritos no curso");
        System.out.println("(B) Corrigir dados do curso");
        System.out.println("(C) Encerrar inscrições");
        System.out.println("(D) Concluir curso");
        System.out.println("(E) Cancelar/Excluir curso");
        System.out.println("\n(R) Retornar ao menu anterior");
        System.out.print("\nOpção: ");
        String entrada = console.nextLine().trim().toUpperCase();
        return entrada.isEmpty() ? ' ' : entrada.charAt(0);
    }

    public Curso leCurso() {
        System.out.println("\n-- Novo Curso --");
        System.out.print("Nome: ");
        String nome = console.nextLine();
        System.out.print("Descrição: ");
        String descricao = console.nextLine();
        System.out.print("Data de início (dd/mm/aaaa): ");
        String dataStr = console.nextLine();
        long dataInicio = 0;
        if (!dataStr.isEmpty()) {
            try {
                dataInicio = sdf.parse(dataStr).getTime();
            } catch (ParseException e) {
                System.out.println("Formato de data inválido. Usando data atual.");
                dataInicio = System.currentTimeMillis();
            }
        }
        return new Curso(-1, -1, nome, descricao, dataInicio, 0, "");
    }

    public void leAlteracaoCurso(Curso c) {
        System.out.println("\n-- Alterar Curso (deixe em branco para manter o valor atual) --");
        System.out.print("Nome [" + c.getNome() + "]: ");
        String nome = console.nextLine();
        if (!nome.isEmpty())
            c.setNome(nome);

        System.out.print("Descrição [" + c.getDescricao() + "]: ");
        String descricao = console.nextLine();
        if (!descricao.isEmpty())
            c.setDescricao(descricao);

        System.out.print("Data de início [" + c.getDataInicioFormatada() + "]: ");
        String dataStr = console.nextLine();
        if (!dataStr.isEmpty()) {
            try {
                c.setDataInicio(sdf.parse(dataStr).getTime());
            } catch (ParseException e) {
                System.out.println("Formato de data inválido. Data não alterada.");
            }
        }
    }

    public boolean confirmaExclusao() {
        System.out.print("\nTem certeza que deseja excluir/cancelar este curso? (S/N): ");
        return console.nextLine().trim().toUpperCase().equals("S");
    }

    public void exibeMensagem(String msg) {
        System.out.println("\n" + msg);
        ConsoleUtils.pausar();
    }
}