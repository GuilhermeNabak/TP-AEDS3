package Views;

import java.util.Scanner;

import Entidades.Curso;
import Menus.ConsoleUtils;

public class VisaoBuscaCurso {

    private static Scanner console = new Scanner(System.in);

    public String leCodigo() {
        ConsoleUtils.limparTela();

        System.out.println("\n\nEntrePares");
        System.out.println("-----------------");
        System.out.println("> Buscar Curso");
        System.out.print("\nDigite o código compartilhável do curso (ou 'R' para retornar): ");
        return console.nextLine().trim();
    }

    public void mostraCursoEncontrado(Curso c) {
        if (c == null) {
            System.out.println("\nNenhum curso encontrado com este código.");
            ConsoleUtils.pausar();
            return;
        }

        System.out.println("\n-- Curso Encontrado --");
        System.out.println("NOME: " + c.getNome());
        System.out.println("DESCRIÇÃO: " + c.getDescricao());
        System.out.println("DATA DE INÍCIO: " + c.getDataInicioFormatada());
        System.out.println("STATUS: " + c.getEstadoDescricao());
        System.out.println("\n(Em breve: visualizar inscrições do curso)");
        System.out.println("----------------------");

        ConsoleUtils.pausar();
    }
}