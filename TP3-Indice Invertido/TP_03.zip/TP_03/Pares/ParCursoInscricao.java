package Pares;

import Registros.RegistroArvoreBMais;
import java.io.*;

public class ParCursoInscricao implements RegistroArvoreBMais<ParCursoInscricao> {
    
    private int idCurso;
    private int idInscricao;
    private final short TAMANHO = 8;
    
    public ParCursoInscricao() {
        this(-1, -1);
    }
    
    public ParCursoInscricao(int idCurso, int idInscricao) {
        this.idCurso = idCurso;
        this.idInscricao = idInscricao;
    }
    
    public int getIdCurso() { return idCurso; }
    public int getIdInscricao() { return idInscricao; }
    
    @Override
    public short size() { return TAMANHO; }
    
    @Override
    public ParCursoInscricao clone() {
        return new ParCursoInscricao(this.idCurso, this.idInscricao);
    }
    
    @Override
    public int compareTo(ParCursoInscricao outro) {
        if (this.idCurso != outro.idCurso) 
            return this.idCurso - outro.idCurso;
        if (this.idInscricao == -1 || outro.idInscricao == -1) return 0;
        return this.idInscricao - outro.idInscricao;
    }
    
    @Override
    public byte[] toByteArray() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        dos.writeInt(this.idCurso);
        dos.writeInt(this.idInscricao);
        return baos.toByteArray();
    }
    
    @Override
    public void fromByteArray(byte[] ba) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(ba);
        DataInputStream dis = new DataInputStream(bais);
        this.idCurso = dis.readInt();
        this.idInscricao = dis.readInt();
    }
}