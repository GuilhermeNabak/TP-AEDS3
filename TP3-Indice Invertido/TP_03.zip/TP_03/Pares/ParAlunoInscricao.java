package Pares;

import java.io.*;
import Registros.RegistroArvoreBMais;

public class ParAlunoInscricao implements RegistroArvoreBMais<ParAlunoInscricao> {
    
    private int idAluno;
    private int idInscricao;
    private final short TAMANHO = 8;
    
    public ParAlunoInscricao() {
        this(-1, -1);
    }
    
    public ParAlunoInscricao(int idAluno, int idInscricao) {
        this.idAluno = idAluno;
        this.idInscricao = idInscricao;
    }
    
    public int getIdAluno() { return idAluno; }
    public int getIdInscricao() { return idInscricao; }
    
    @Override
    public short size() { return TAMANHO; }
    
    @Override
    public ParAlunoInscricao clone() {
        return new ParAlunoInscricao(this.idAluno, this.idInscricao);
    }
    
    @Override
    public int compareTo(ParAlunoInscricao outro) {
        if (this.idAluno != outro.idAluno)
            return this.idAluno - outro.idAluno;
        if (this.idInscricao == -1 || outro.idInscricao == -1)
            return 0;
        return this.idInscricao - outro.idInscricao;
    }
    
    @Override
    public byte[] toByteArray() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        dos.writeInt(this.idAluno);
        dos.writeInt(this.idInscricao);
        return baos.toByteArray();
    }
    
    @Override
    public void fromByteArray(byte[] ba) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(ba);
        DataInputStream dis = new DataInputStream(bais);
        this.idAluno = dis.readInt();
        this.idInscricao = dis.readInt();
    }
}