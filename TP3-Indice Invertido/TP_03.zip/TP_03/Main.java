import java.util.Scanner;
import Menus.ConsoleUtils;
import Menus.MenuUsuarios;

public class Main {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        MenuUsuarios menuUsuarios;

        try {
            menuUsuarios = new MenuUsuarios();

            char opcao;
            do {
                ConsoleUtils.limparTela();

                System.out.println("\n\nEntrePares");
                System.out.println("------------------");
                System.out.println("\n(A) Login");
                System.out.println("(B) Novo usuário");
                System.out.println("(S) Sair");

                System.out.print("\nOpção: ");
                String entrada = console.nextLine().trim().toUpperCase();
                
                // CORRIGIDO: verificar se entrada não está vazia
                if (entrada.isEmpty()) {
                    opcao = ' ';
                } else {
                    opcao = entrada.charAt(0);
                }

                switch (opcao) {
                    case 'A':
                        menuUsuarios.login();
                        break;
                    case 'B':
                        menuUsuarios.incluirUsuario();
                        break;
                    case 'S':
                        System.out.println("Saindo...");
                        break;
                    default:
                        System.out.println("Opção inválida!");
                        ConsoleUtils.pausar();
                        break;
                }
            } while (opcao != 'S'); // CORRIGIDO: condição de saída

        } catch (Exception e) {
            System.out.println("Erro fatal: " + e.getMessage());
            e.printStackTrace();
        } finally {
            console.close(); // Fecha o scanner
        }
    }
}