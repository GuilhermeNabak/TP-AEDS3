package Controles;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import Arquivo.ArquivoCurso;
import Arquivo.ArquivoInscricao;
import Arquivo.ArquivoUsuario;
import Entidades.Curso;
import Entidades.Inscricao;
import Entidades.Usuario;
import Pares.ParAlunoInscricao;
import Views.VisaoInscricao;

public class ControleMinhasInscricoes {
    
    private ArquivoCurso arqCursos;
    private ArquivoInscricao arqInscricoes;
    private VisaoInscricao visao;
    private Usuario alunoLogado;
    
    public ControleMinhasInscricoes(Usuario alunoLogado) throws Exception {
        this.arqCursos = new ArquivoCurso();
        this.arqInscricoes = new ArquivoInscricao();
        this.visao = new VisaoInscricao();
        this.alunoLogado = alunoLogado;
    }
    
    public void executa() throws Exception {
        char opcao;
        do {
            List<Curso> meusCursos = carregarMeusCursos();
            opcao = visao.mostraMenuMinhasInscricoes(meusCursos);
            
            switch (opcao) {
                case 'A':
                    buscarCursoPorCodigo();
                    break;
                case 'B':
                    buscarCursoPorPalavrasChave();
                    break;    
                case 'C':
                    listarTodosCursos();
                    break;
                case 'R':
                    break;
                default:
                    try {
                        int idx = Integer.parseInt(String.valueOf(opcao)) - 1;
                        if (idx >= 0 && idx < meusCursos.size()) {
                            cancelarInscricao(meusCursos.get(idx));
                        }
                    } catch (NumberFormatException e) {
                        if (opcao != 'R') {
                            visao.exibeMensagem("Opção inválida!");
                        }
                    }
                    break;
            }
        } while (opcao != 'R');
    }
    
    private List<Curso> carregarMeusCursos() throws Exception {
        List<Curso> cursos = new ArrayList<>();
        List<ParAlunoInscricao> inscricoes = arqInscricoes.getInscricoesPorAluno(alunoLogado.getId());
        
        for (ParAlunoInscricao par : inscricoes) {
            Inscricao insc = arqInscricoes.read(par.getIdInscricao());
            if (insc != null) {
                Curso curso = arqCursos.read(insc.getIdCurso());
                if (curso != null) {
                    cursos.add(curso);
                }
            }
        }
        return cursos;
    }
    
    private void buscarCursoPorCodigo() throws Exception {
        String codigo = visao.leCodigoBusca();
        if (codigo.isEmpty()) return;
        
        Curso curso = arqCursos.readByCodigo(codigo);
        if (curso == null) {
            visao.exibeMensagem("Curso não encontrado!");
            return;
        }
        
        realizarInscricaoSelecionada(curso);
    }

    private void buscarCursoPorPalavrasChave() throws Exception {
        String palavras = visao.lePalavrasChave();
        if (palavras.isEmpty()) return;

        List<Curso> cursosEncontrados = arqCursos.readByNomes(palavras);
        if (cursosEncontrados == null || cursosEncontrados.isEmpty()) {
            visao.exibeMensagem("Nenhum curso encontrado com essas palavras-chave!");
            return;
        }

        char opcao = visao.mostraCursosEncontrados(cursosEncontrados);
        try {
            int idx = Integer.parseInt(String.valueOf(opcao)) - 1;
            if (idx >= 0 && idx < cursosEncontrados.size()) {
                realizarInscricaoSelecionada(cursosEncontrados.get(idx));
            }
        } catch (NumberFormatException e) {
            // Volta pro menu ou opcao 'R'
        }
    }

    private void realizarInscricaoSelecionada(Curso curso) throws Exception {
        boolean jaInscrito = arqInscricoes.isInscrito(alunoLogado.getId(), curso.getId());
        int vagasRestantes = 30 - arqInscricoes.countAlunosDoCurso(curso.getId());
        
        char opcao = visao.mostraDetalhesCursoInscricao(curso, jaInscrito, vagasRestantes);
        
        if (opcao == 'A' && !jaInscrito && curso.getEstado() == 0 && vagasRestantes > 0) {
            if (visao.confirma("Confirmar inscrição?")) {
                Inscricao nova = new Inscricao();
                nova.setIdCurso(curso.getId());
                nova.setIdAluno(alunoLogado.getId());
                arqInscricoes.create(nova);
                visao.exibeMensagem("Inscrição realizada com sucesso!");
            }
        }
    }
    
    private void listarTodosCursos() throws Exception {
        List<Curso> todosCursos = arqCursos.readAll();
        if (todosCursos.isEmpty()) {
            visao.exibeMensagem("Nenhum curso disponível.");
            return;
        }
        
        Collections.sort(todosCursos, new Comparator<Curso>() {
        @Override
        public int compare(Curso a, Curso b) {
            return Long.compare(a.getDataInicio(), b.getDataInicio());
        }
    });
        
        int pagina = 1;
        int totalPaginas = (int) Math.ceil(todosCursos.size() / 10.0);
        
        char opcao;
        do {
            opcao = visao.mostraListaCursosPaginada(todosCursos, pagina, totalPaginas);
            
            switch (opcao) {
                case 'A':
                    if (pagina > 1) pagina--;
                    break;
                case 'B':
                    if (pagina < totalPaginas) pagina++;
                    break;
                case 'R':
                    break;
                default:
                    try {
                        int num = Integer.parseInt(String.valueOf(opcao));
                        if (num == 0) num = 10;
                        int idx = (pagina - 1) * 10 + (num - 1);
                        if (idx >= 0 && idx < todosCursos.size()) {
                            visualizarCursoParaInscricao(todosCursos.get(idx));
                        }
                    } catch (NumberFormatException e) {}
                    break;
            }
        } while (opcao != 'R');
    }
    
    private void visualizarCursoParaInscricao(Curso curso) throws Exception {
        boolean jaInscrito = arqInscricoes.isInscrito(alunoLogado.getId(), curso.getId());
        int vagasRestantes = 30 - arqInscricoes.countAlunosDoCurso(curso.getId());
        
        char opcao = visao.mostraDetalhesCursoInscricao(curso, jaInscrito, vagasRestantes);
        
        if (opcao == 'A' && !jaInscrito && curso.getEstado() == 0 && vagasRestantes > 0) {
            if (visao.confirma("Confirmar inscrição?")) {
                Inscricao nova = new Inscricao();
                nova.setIdCurso(curso.getId());
                nova.setIdAluno(alunoLogado.getId());
                arqInscricoes.create(nova);
                visao.exibeMensagem("Inscrição realizada!");
            }
        }
    }
    
    private void cancelarInscricao(Curso curso) throws Exception {
        char opcao = visao.mostraDetalhesCursoCancelamento(curso);
        
        if (opcao == 'A') {
            if (visao.confirma("Cancelar inscrição?")) {
                List<ParAlunoInscricao> inscricoes = arqInscricoes.getInscricoesPorAluno(alunoLogado.getId());
                for (ParAlunoInscricao par : inscricoes) {
                    Inscricao ins = arqInscricoes.read(par.getIdInscricao());
                    if (ins != null && ins.getIdCurso() == curso.getId()) {
                        arqInscricoes.delete(ins.getId());
                        visao.exibeMensagem("Inscrição cancelada!");
                        break;
                    }
                }
            }
        }
    }
    
    public void close() throws Exception {
        if (arqCursos != null) arqCursos.close();
        if (arqInscricoes != null) arqInscricoes.close();
    }
}