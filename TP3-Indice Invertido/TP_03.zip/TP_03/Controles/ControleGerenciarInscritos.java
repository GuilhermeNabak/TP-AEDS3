package Controles;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import Arquivo.ArquivoCurso;
import Arquivo.ArquivoInscricao;
import Arquivo.ArquivoUsuario;
import Entidades.Curso;
import Entidades.Inscricao;
import Entidades.Usuario;
import Pares.ParCursoInscricao;
import Views.VisaoInscricao;

public class ControleGerenciarInscritos {
    
    private ArquivoCurso arqCursos;
    private ArquivoInscricao arqInscricoes;
    private ArquivoUsuario arqUsuarios;
    private VisaoInscricao visao;
    
    public ControleGerenciarInscritos() throws Exception {
        this.arqCursos = new ArquivoCurso();
        this.arqInscricoes = new ArquivoInscricao();
        this.arqUsuarios = new ArquivoUsuario();
        this.visao = new VisaoInscricao();
    }
    
    public void gerenciar(Curso curso) throws Exception {
        char opcao;
        do {
            List<Usuario> alunos = new ArrayList<>();
            List<Inscricao> inscricoes = new ArrayList<>();
            
            List<ParCursoInscricao> associacoes = arqInscricoes.getInscricoesPorCurso(curso.getId());
            for (ParCursoInscricao par : associacoes) {
                Inscricao ins = arqInscricoes.read(par.getIdInscricao());
                if (ins != null) {
                    Usuario aluno = arqUsuarios.read(ins.getIdAluno());
                    if (aluno != null) {
                        alunos.add(aluno);
                        inscricoes.add(ins);
                    }
                }
            }
            
            opcao = visao.mostraMenuGerenciarInscritos(curso, alunos, inscricoes);
            
            switch (opcao) {
                case 'A':
                    exportarCSV(curso, alunos);
                    break;
                case 'R':
                    break;
                default:
                    try {
                        int idx = Integer.parseInt(String.valueOf(opcao)) - 1;
                        if (idx >= 0 && idx < alunos.size()) {
                            gerenciarAluno(curso, alunos.get(idx), inscricoes.get(idx));
                        }
                    } catch (NumberFormatException e) {}
                    break;
            }
        } while (opcao != 'R');
    }
    
    private void gerenciarAluno(Curso curso, Usuario aluno, Inscricao inscricao) throws Exception {
        char opcao = visao.mostraMenuGerenciarAluno(aluno, curso);
        
        if (opcao == 'A') {
            if (visao.confirma("Cancelar inscrição de " + aluno.getNome() + "?")) {
                arqInscricoes.delete(inscricao.getId());
                visao.exibeMensagem("Inscrição cancelada!");
            }
        }
    }
    
    private void exportarCSV(Curso curso, List<Usuario> alunos) throws Exception {
        String nomeArquivo = "inscritos_curso_" + curso.getId() + "_" + 
                             new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".csv";
        
        try (PrintWriter writer = new PrintWriter(new FileWriter(nomeArquivo))) {
            writer.println("Nome,Email");
            for (Usuario aluno : alunos) {
                writer.printf("\"%s\",\"%s\"\n", aluno.getNome(), aluno.getEmail());
            }
        }
        
        visao.exibeMensagem("Exportado para: " + nomeArquivo);
    }
    
    public void close() throws Exception {
        if (arqCursos != null) arqCursos.close();
        if (arqInscricoes != null) arqInscricoes.close();
        if (arqUsuarios != null) arqUsuarios.close();
    }
}