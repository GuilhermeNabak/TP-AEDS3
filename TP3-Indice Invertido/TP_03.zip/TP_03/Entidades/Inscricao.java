package Entidades;

import java.io.*;
import Registros.Registro;

public class Inscricao implements Registro {
    
    private int id;
    private int idCurso;
    private int idAluno;
    private long dataInscricao;
    
    public Inscricao() {
        this(-1, -1, -1, System.currentTimeMillis());
    }
    
    public Inscricao(int id, int idCurso, int idAluno, long dataInscricao) {
        this.id = id;
        this.idCurso = idCurso;
        this.idAluno = idAluno;
        this.dataInscricao = dataInscricao;
    }
    
    @Override
    public int getId() { return id; }
    @Override
    public void setId(int id) { this.id = id; }
    
    public int getIdCurso() { return idCurso; }
    public void setIdCurso(int idCurso) { this.idCurso = idCurso; }
    
    public int getIdAluno() { return idAluno; }
    public void setIdAluno(int idAluno) { this.idAluno = idAluno; }
    
    public long getDataInscricao() { return dataInscricao; }
    public void setDataInscricao(long dataInscricao) { this.dataInscricao = dataInscricao; }
    
    public String getDataInscricaoFormatada() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(new java.util.Date(dataInscricao));
    }
    
    @Override
    public byte[] toByteArray() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        dos.writeInt(id);
        dos.writeInt(idCurso);
        dos.writeInt(idAluno);
        dos.writeLong(dataInscricao);
        return baos.toByteArray();
    }
    
    @Override
    public void fromByteArray(byte[] ba) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(ba);
        DataInputStream dis = new DataInputStream(bais);
        this.id = dis.readInt();
        this.idCurso = dis.readInt();
        this.idAluno = dis.readInt();
        this.dataInscricao = dis.readLong();
    }
}