package Entidades;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import Registros.Registro;

public class Curso implements Registro {

    private int id;
    private int idUsuario;
    private String nome;
    private String descricao;
    private long dataInicio;
    private int estado; // 0-ativo c/ inscrições, 1-ativo s/ inscrições, 2-concluído, 3-cancelado
    private String codigoCompartilhavel;

    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    public Curso() {
        this(-1, -1, "", "", 0, 0, "");
    }

    public Curso(int id, int idUsuario, String nome, String descricao, long dataInicio, int estado, String codigo) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.nome = nome;
        this.descricao = descricao;
        this.dataInicio = dataInicio;
        this.estado = estado;
        this.codigoCompartilhavel = codigo;
    }

    // Getters
    public int getId() { return id; }
    public int getIdUsuario() { return idUsuario; }
    public String getNome() { return nome; }
    public String getDescricao() { return descricao; }
    public String getCodigoCompartilhavel() { return codigoCompartilhavel; }
    public int getEstado() { return estado; }
    
    public String getDataInicioFormatada() {
        return sdf.format(new Date(this.dataInicio));
    }
    
    public String getEstadoDescricao() {
        switch(estado) {
            case 0: return "Ativo e recebendo inscrições";
            case 1: return "Ativo, mas sem novas inscrições";
            case 2: return "Realizado e concluído";
            case 3: return "Cancelado";
            default: return "Desconhecido";
        }
    }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setIdUsuario(int id) { this.idUsuario = id; }
    public void setNome(String n) { this.nome = n; }
    public void setDescricao(String d) { this.descricao = d; }
    public void setDataInicio(long d) { this.dataInicio = d; }
    public void setEstado(int e) { this.estado = e; }
    public void setCodigoCompartilhavel(String c) { this.codigoCompartilhavel = c; }

    @Override
    public byte[] toByteArray() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        dos.writeInt(id);
        dos.writeInt(idUsuario);
        dos.writeUTF(nome);
        dos.writeUTF(descricao);
        dos.writeLong(dataInicio);
        dos.writeInt(estado);
        dos.writeUTF(codigoCompartilhavel);
        return baos.toByteArray();
    }

    @Override
    public void fromByteArray(byte[] ba) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(ba);
        DataInputStream dis = new DataInputStream(bais);
        this.id = dis.readInt();
        this.idUsuario = dis.readInt();
        this.nome = dis.readUTF();
        this.descricao = dis.readUTF();
        this.dataInicio = dis.readLong();
        this.estado = dis.readInt();
        this.codigoCompartilhavel = dis.readUTF();
    }
    public long getDataInicio() {
    return dataInicio;
}
}