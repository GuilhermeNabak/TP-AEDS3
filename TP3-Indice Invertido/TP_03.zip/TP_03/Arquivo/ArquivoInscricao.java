package Arquivo;

import java.util.ArrayList;
import java.util.List;
import Entidades.Inscricao;
import Estruturas.ArvoreBMais;
import Pares.ParCursoInscricao;
import Pares.ParAlunoInscricao;

public class ArquivoInscricao extends Arquivo<Inscricao> {
    
    private ArvoreBMais<ParCursoInscricao> indiceCursoInscricao;
    private ArvoreBMais<ParAlunoInscricao> indiceAlunoInscricao;
    
    public ArquivoInscricao() throws Exception {
        super("inscricoes", Inscricao.class.getConstructor());
        
        // Criar diretório se não existir
        java.io.File d = new java.io.File("Dados/inscricoes");
        if (!d.exists()) d.mkdirs();
        
        indiceCursoInscricao = new ArvoreBMais<>(
            ParCursoInscricao.class.getConstructor(), 
            5, 
            "Dados/inscricoes/cursoInscricao.idx"
        );
        
        indiceAlunoInscricao = new ArvoreBMais<>(
            ParAlunoInscricao.class.getConstructor(), 
            5, 
            "Dados/inscricoes/alunoInscricao.idx"
        );
    }
    
    public List<ParCursoInscricao> getInscricoesPorCurso(int idCurso) throws Exception {
        return indiceCursoInscricao.read(new ParCursoInscricao(idCurso, -1));
    }
    
    public List<ParAlunoInscricao> getInscricoesPorAluno(int idAluno) throws Exception {
        return indiceAlunoInscricao.read(new ParAlunoInscricao(idAluno, -1));
    }
    
    public boolean isInscrito(int idAluno, int idCurso) throws Exception {
        List<ParAlunoInscricao> inscricoes = getInscricoesPorAluno(idAluno);
        for (ParAlunoInscricao par : inscricoes) {
            Inscricao insc = super.read(par.getIdInscricao());
            if (insc != null && insc.getIdCurso() == idCurso) {
                return true;
            }
        }
        return false;
    }
    
    public int countAlunosDoCurso(int idCurso) throws Exception {
        return getInscricoesPorCurso(idCurso).size();
    }
    
    @Override
    public int create(Inscricao obj) throws Exception {
        if (isInscrito(obj.getIdAluno(), obj.getIdCurso())) {
            throw new Exception("Aluno já está inscrito neste curso.");
        }
        
        if (countAlunosDoCurso(obj.getIdCurso()) >= 30) {
            throw new Exception("Curso lotado! Máximo de 30 alunos.");
        }
        
        int id = super.create(obj);
        obj.setId(id);
        
        indiceCursoInscricao.create(new ParCursoInscricao(obj.getIdCurso(), id));
        indiceAlunoInscricao.create(new ParAlunoInscricao(obj.getIdAluno(), id));
        
        return id;
    }
    
    @Override
    public boolean delete(int idInscricao) throws Exception {
        Inscricao insc = super.read(idInscricao);
        if (insc == null) return false;
        
        if (super.delete(idInscricao)) {
            indiceCursoInscricao.delete(new ParCursoInscricao(insc.getIdCurso(), idInscricao));
            indiceAlunoInscricao.delete(new ParAlunoInscricao(insc.getIdAluno(), idInscricao));
            return true;
        }
        return false;
    }
    
    @Override
    public void close() throws Exception {
        super.close();
    }
}