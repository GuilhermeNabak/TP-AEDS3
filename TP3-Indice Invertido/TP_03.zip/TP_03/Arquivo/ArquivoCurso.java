package Arquivo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import Entidades.Curso;
import Estruturas.ArvoreBMais;
import Estruturas.HashExtensivel;
import Estruturas.ListaInvertida;
import Estruturas.ElementoLista;
import Pares.ParCodigoCurso;
import Pares.ParUsuarioCurso;

public class ArquivoCurso extends Arquivo<Curso> {

    private ArvoreBMais<ParUsuarioCurso> indiceUsuarioCurso;
    private HashExtensivel<ParCodigoCurso> indiceCodigoCurso;
    private ListaInvertida indiceNomeCurso;

    public ArquivoCurso() throws Exception {
        super("cursos", Curso.class.getConstructor());
        
        indiceUsuarioCurso = new ArvoreBMais<>(ParUsuarioCurso.class.getConstructor(), 5, "dados/cursos/usuarioCurso.idx");
        indiceCodigoCurso = new HashExtensivel<>(ParCodigoCurso.class.getConstructor(), 4, 
                "dados/cursos/codigoCurso.d.db", "dados/cursos/codigoCurso.c.db");
        indiceNomeCurso = new ListaInvertida(4, "dados/cursos/nomeCurso.d.db", "dados/cursos/nomeCurso.c.db");
    }

    public Curso readByCodigo(String codigo) throws Exception {
        ParCodigoCurso pBusca = new ParCodigoCurso(codigo, -1);
        int hashCodeBusca = pBusca.hashCode();
        ParCodigoCurso pEncontrado = indiceCodigoCurso.read(hashCodeBusca);

        if (pEncontrado != null && pEncontrado.getCodigo().equals(codigo)) {
            return super.read(pEncontrado.getIdCurso());
        }
        return null;
    }

    public List<Curso> readAll(int idUsuario) throws Exception {
        List<Curso> cursosDoUsuario = new ArrayList<>();
        ArrayList<ParUsuarioCurso> pares = indiceUsuarioCurso.read(new ParUsuarioCurso(idUsuario, -1));
        
        for (ParUsuarioCurso par : pares) {
            Curso curso = super.read(par.getIdCurso());
            if (curso != null) {
                cursosDoUsuario.add(curso);
            }
        }
        return cursosDoUsuario;
    }

    private String[] getTermos(String texto) {
        String textoLimpo = texto.toLowerCase().replaceAll("[^\\p{L}\\p{Nd}]+", " ");
        String[] palavras = textoLimpo.split("\\s+");
        List<String> validas = new ArrayList<>();
        
        List<String> stopwords = java.util.Arrays.asList(
            "a", "o", "as", "os", "um", "uma", "uns", "umas",
            "de", "do", "da", "dos", "das",
            "em", "no", "na", "nos", "nas",
            "por", "pelo", "pela", "pelos", "pelas",
            "para", "pro", "pra",
            "a", "ao", "aos", "à", "às",
            "com", "sem", "sobre", "sob",
            "e", "ou", "nem", "que", "qual", "se",
            "curso", "formação", "treinamento", "capacitação"
        );
        
        for(String p : palavras) {
            // Remove stops words and keep other words
            if(!p.isEmpty() && !stopwords.contains(p)) {
                validas.add(p);
            }
        }
        return validas.toArray(new String[0]);
    }

    private void insereTermos(Curso obj) throws Exception {
        String[] termos = getTermos(obj.getNome());
        if (termos.length == 0) return;
        Map<String, Integer> freq = new HashMap<>();
        for (String t : termos) {
            freq.put(t, freq.getOrDefault(t, 0) + 1);
        }
        
        for (String termo : freq.keySet()) {
            float tf = (float) freq.get(termo) / termos.length;
            ElementoLista elem = new ElementoLista(obj.getId(), tf);
            indiceNomeCurso.create(termo, elem);
        }
    }

    private void removeTermos(Curso obj) throws Exception {
        String[] termos = getTermos(obj.getNome());
        for (String t : termos) {
            indiceNomeCurso.delete(t, obj.getId());
        }
    }

    public List<Curso> readByNomes(String pesquisa) throws Exception {
        String[] termos = getTermos(pesquisa);
        if (termos.length == 0) return new ArrayList<>();

        Map<Integer, Float> pontuacaoDocs = new HashMap<>();

        for (String termo : termos) {
            ElementoLista[] elementos = indiceNomeCurso.read(termo);
            for (ElementoLista e : elementos) {
                pontuacaoDocs.put(e.getId(), pontuacaoDocs.getOrDefault(e.getId(), 0f) + e.getFrequencia());
            }
        }

        // Ordenar os IDs pela pontuação (do maior pro menor)
        List<Map.Entry<Integer, Float>> listaPontuacoes = new ArrayList<>(pontuacaoDocs.entrySet());
        listaPontuacoes.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()));

        List<Curso> cursosEncontrados = new ArrayList<>();
        for (Map.Entry<Integer, Float> entry : listaPontuacoes) {
            Curso c = super.read(entry.getKey());
            if (c != null) {
                cursosEncontrados.add(c);
            }
        }

        return cursosEncontrados;
    }
    
    @Override
    public int create(Curso obj) throws Exception {
        obj.setCodigoCompartilhavel(ArquivoNanoID.generate());
        int idCurso = super.create(obj);
        obj.setId(idCurso);
        
        indiceUsuarioCurso.create(new ParUsuarioCurso(obj.getIdUsuario(), idCurso));
        indiceCodigoCurso.create(new ParCodigoCurso(obj.getCodigoCompartilhavel(), idCurso));
        
        insereTermos(obj);
        indiceNomeCurso.incrementaEntidades();
        
        return idCurso;
    }

    @Override
    public boolean delete(int idCurso) throws Exception {
        Curso curso = super.read(idCurso);
        if (curso == null) return false;

        if (super.delete(idCurso)) {
            ParCodigoCurso pDelete = new ParCodigoCurso(curso.getCodigoCompartilhavel(), -1);
            int hashCodeDelete = pDelete.hashCode();
            indiceCodigoCurso.delete(hashCodeDelete);
            indiceUsuarioCurso.delete(new ParUsuarioCurso(curso.getIdUsuario(), idCurso));
            
            removeTermos(curso);
            indiceNomeCurso.decrementaEntidades();
            
            return true;
        }
        return false;
    }

    @Override
    public boolean update(Curso novo) throws Exception {
        Curso antigo = super.read(novo.getId());
        if (antigo != null && super.update(novo)) {
            if (!antigo.getNome().equals(novo.getNome())) {
                removeTermos(antigo);
                insereTermos(novo);
            }
            return true;
        }
        return false;
    }

    public List<Curso> readAll() throws Exception {
    List<Curso> cursos = new ArrayList<>();
    
    arquivo.seek(0);
    int ultimoId = arquivo.readInt();
    
    for (int id = 1; id <= ultimoId; id++) {
        Curso c = read(id);
        if (c != null) {
            cursos.add(c);
        }
    }
    
    return cursos;
}

}