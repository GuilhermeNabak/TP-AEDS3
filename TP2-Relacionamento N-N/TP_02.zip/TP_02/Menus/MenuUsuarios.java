package Menus;

import Arquivo.*;
import Entidades.*;
import Controles.*;

import java.util.Scanner;
import java.security.MessageDigest;
import java.util.List;

public class MenuUsuarios {

    private ArquivoUsuario arqUsuarios;
    private Usuario usuarioAtivo;
    private static Scanner console = new Scanner(System.in);

    public MenuUsuarios() throws Exception {
        arqUsuarios = new ArquivoUsuario();
    }

    public void incluirUsuario() {
        System.out.println("\nInclusão de usuário");
        try {
            String nome;
            do {
                System.out.print("Nome (min 4 chars, vazio p/ cancelar): ");
                nome = console.nextLine();
                if (nome.length() == 0) return;
                if (nome.length() < 4) System.out.println("Nome muito curto.");
            } while(nome.length() < 4);

            String email;
            do {
                System.out.print("Email (vazio p/ cancelar): ");
                email = console.nextLine().trim();
                if (email.isEmpty()) return;
                if (!email.contains("@")) System.out.println("Email inválido.");
            } while(!email.contains("@"));

            if (arqUsuarios.read(email) != null) {
                System.out.println("Email já cadastrado.");
                ConsoleUtils.pausar();
                return;
            }

            System.out.print("Senha: ");
            String senha = console.nextLine();

            System.out.print("Pergunta secreta (para recuperação): ");
            String pergunta = console.nextLine();

            System.out.print("Resposta secreta: ");
            String resposta = console.nextLine();

            String hash = hashSenha(senha);

            arqUsuarios.create(new Usuario(-1, nome, email, hash, pergunta, resposta));
            System.out.println("Usuário cadastrado com sucesso.");
            ConsoleUtils.pausar();

        } catch(Exception e) {
            System.out.println("Erro ao incluir usuário: " + e.getMessage());
            ConsoleUtils.pausar();
        }
    }

    public void login() {
        System.out.println("\nLogin");
        System.out.print("Email: ");
        String email = console.nextLine().trim();
        if (email.isEmpty()) return;

        System.out.print("Senha: ");
        String senha = console.nextLine();

        try {
            Usuario u = arqUsuarios.read(email);
            if (u == null) {
                System.out.println("Usuário não encontrado.");
                ConsoleUtils.pausar();
                return;
            }

            String hash = hashSenha(senha);
            if (hash.equals(u.getHashSenha())) {
                usuarioAtivo = u;
                System.out.println("\nLogin bem-sucedido. Bem-vindo, " + u.getNome() + "!");
                ConsoleUtils.pausar();
                menuPrincipalUsuario();
            } else {
                System.out.println("Senha incorreta.");
                ConsoleUtils.pausar();
            }
        } catch(Exception e) {
            System.out.println("Erro no login: " + e.getMessage());
            ConsoleUtils.pausar();
        }
    }

    private void menuPrincipalUsuario() {
        char opcao;
        boolean contaExcluida = false;
        do {
            ConsoleUtils.limparTela();

            System.out.println("\n\nEntrePares 1.0");
            System.out.println("-----------------");
            System.out.println("> Início");
            System.out.println("\n(A) Meus dados");
            System.out.println("(B) Meus cursos");
            System.out.println("(C) Minhas inscrições");
            System.out.println("\n(S) Sair");

            System.out.print("\nOpção: ");
            String entrada = console.nextLine().trim().toUpperCase();
            opcao = entrada.isEmpty() ? ' ' : entrada.charAt(0);

            switch (opcao) {
                case 'A':
                    try {
                        ControleUsuario controleUsuario = new ControleUsuario(usuarioAtivo);
                        if (controleUsuario.executa()) {
                            contaExcluida = true;
                        }
                    } catch(Exception e) {
                        System.out.println("Erro: " + e.getMessage());
                        ConsoleUtils.pausar();
                    }
                    break;
                case 'B': 
                    try {
                        ControleCurso controleCurso = new ControleCurso(usuarioAtivo);
                        controleCurso.executa();
                    } catch(Exception e) {
                        System.out.println("Erro: " + e.getMessage());
                        ConsoleUtils.pausar();
                    }
                    break;
                case 'C':
                    try {
                        ControleMinhasInscricoes controle = new ControleMinhasInscricoes(usuarioAtivo);
                        controle.executa();
                        controle.close();
                    } catch (Exception e) {
                        System.out.println("Erro: " + e.getMessage());
                        ConsoleUtils.pausar();
                    }
                    break;
                case 'S': 
                    System.out.println("\nSaindo da sua conta..."); 
                    usuarioAtivo = null;
                    break;
                default: 
                    System.out.println("\nOpção inválida!"); 
                    ConsoleUtils.pausar();
                    break;
            }

        } while (opcao != 'S' && !contaExcluida);

        if (contaExcluida) {
            usuarioAtivo = null;
        }
    }

    private String hashSenha(String senha) {
        try {
            senha = senha.trim();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(senha.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Usuario getUsuarioAtivo() {
        return usuarioAtivo;
    }
}