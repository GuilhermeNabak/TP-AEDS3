package Arquivo;

import java.util.ArrayList;
import java.util.List;
import Entidades.Curso;
import Estruturas.ArvoreBMais;
import Estruturas.HashExtensivel;
import Pares.ParCodigoCurso;
import Pares.ParUsuarioCurso;

public class ArquivoCurso extends Arquivo<Curso> {

    private ArvoreBMais<ParUsuarioCurso> indiceUsuarioCurso;
    private HashExtensivel<ParCodigoCurso> indiceCodigoCurso;

    public ArquivoCurso() throws Exception {
        super("cursos", Curso.class.getConstructor());
        
        indiceUsuarioCurso = new ArvoreBMais<>(ParUsuarioCurso.class.getConstructor(), 5, "dados/cursos/usuarioCurso.idx");
        indiceCodigoCurso = new HashExtensivel<>(ParCodigoCurso.class.getConstructor(), 4, 
                "dados/cursos/codigoCurso.d.db", "dados/cursos/codigoCurso.c.db");
    }

    public Curso readByCodigo(String codigo) throws Exception {
        ParCodigoCurso pBusca = new ParCodigoCurso(codigo, -1);
        int hashCodeBusca = pBusca.hashCode();
        ParCodigoCurso pEncontrado = indiceCodigoCurso.read(hashCodeBusca);

        if (pEncontrado != null && pEncontrado.getCodigo().equals(codigo)) {
            return super.read(pEncontrado.getIdCurso());
        }
        return null;
    }

    public List<Curso> readAll(int idUsuario) throws Exception {
        List<Curso> cursosDoUsuario = new ArrayList<>();
        ArrayList<ParUsuarioCurso> pares = indiceUsuarioCurso.read(new ParUsuarioCurso(idUsuario, -1));
        
        for (ParUsuarioCurso par : pares) {
            Curso curso = super.read(par.getIdCurso());
            if (curso != null) {
                cursosDoUsuario.add(curso);
            }
        }
        return cursosDoUsuario;
    }
    
    @Override
    public int create(Curso obj) throws Exception {
        obj.setCodigoCompartilhavel(ArquivoNanoID.generate());
        int idCurso = super.create(obj);
        obj.setId(idCurso);
        
        indiceUsuarioCurso.create(new ParUsuarioCurso(obj.getIdUsuario(), idCurso));
        indiceCodigoCurso.create(new ParCodigoCurso(obj.getCodigoCompartilhavel(), idCurso));
        
        return idCurso;
    }

    @Override
    public boolean delete(int idCurso) throws Exception {
        Curso curso = super.read(idCurso);
        if (curso == null) return false;

        if (super.delete(idCurso)) {
            ParCodigoCurso pDelete = new ParCodigoCurso(curso.getCodigoCompartilhavel(), -1);
            int hashCodeDelete = pDelete.hashCode();
            indiceCodigoCurso.delete(hashCodeDelete);
            indiceUsuarioCurso.delete(new ParUsuarioCurso(curso.getIdUsuario(), idCurso));
            return true;
        }
        return false;
    }

    public List<Curso> readAll() throws Exception {
    List<Curso> cursos = new ArrayList<>();
    
    arquivo.seek(0);
    int ultimoId = arquivo.readInt();
    
    for (int id = 1; id <= ultimoId; id++) {
        Curso c = read(id);
        if (c != null) {
            cursos.add(c);
        }
    }
    
    return cursos;
}

}