package Views;

import Entidades.Curso;
import Entidades.Inscricao;
import Entidades.Usuario;
import Menus.ConsoleUtils;
import java.util.List;
import java.util.Scanner;

public class VisaoInscricao {
    
    private static Scanner console = new Scanner(System.in);
    
    // Menu principal do aluno
    public char mostraMenuMinhasInscricoes(List<Curso> meusCursos) {
        ConsoleUtils.limparTela();
        
        System.out.println("\n\nEntrePares 1.0");
        System.out.println("-----------------");
        System.out.println("> Início > Minhas inscrições");
        System.out.println("\nINSCRIÇÕES");
        
        if (meusCursos.isEmpty()) {
            System.out.println("Nenhum curso encontrado.");
        } else {
            for (int i = 0; i < meusCursos.size(); i++) {
                Curso c = meusCursos.get(i);
                System.out.printf("%d. %s - %s\n", i + 1, c.getNome(), c.getDataInicioFormatada());
            }
        }
        
        System.out.println("\n(A) Buscar curso por código");
        System.out.println("(B) Buscar curso por palavras-chave (TP3)");
        System.out.println("(C) Listar todos os cursos");
        System.out.println("\n(R) Retornar ao menu anterior");
        System.out.print("\nOpção: ");
        
        String entrada = console.nextLine().trim().toUpperCase();
        return entrada.isEmpty() ? ' ' : entrada.charAt(0);
    }
    
    // Lista de cursos com paginação
    public char mostraListaCursosPaginada(List<Curso> cursos, int pagina, int totalPaginas) {
        ConsoleUtils.limparTela();
        
        System.out.println("\n\nEntrePares 1.0");
        System.out.println("-----------------");
        System.out.println("> Início > Minhas inscrições > Lista de cursos");
        System.out.printf("\nPágina %d de %d\n", pagina, totalPaginas);
        
        int inicio = (pagina - 1) * 10;
        int fim = Math.min(inicio + 10, cursos.size());
        
        for (int i = inicio; i < fim; i++) {
            Curso c = cursos.get(i);
            int numDisplay = (i % 10) + 1;
            if (numDisplay == 10) numDisplay = 0;
            System.out.printf("(%d) %s - %s\n", numDisplay, c.getNome(), c.getDataInicioFormatada());
        }
        
        System.out.println("\n(A) Página anterior");
        System.out.println("(B) Próxima página");
        System.out.println("\n(R) Retornar");
        System.out.print("\nOpção: ");
        
        String entrada = console.nextLine().trim().toUpperCase();
        return entrada.isEmpty() ? ' ' : entrada.charAt(0);
    }
    
    // Detalhes do curso para inscrição
    public char mostraDetalhesCursoInscricao(Curso curso, boolean jaInscrito, int vagasRestantes) {
        ConsoleUtils.limparTela();
        
        System.out.println("\n\nEntrePares 1.0");
        System.out.println("-----------------");
        System.out.println("> Início > Minhas inscrições > " + curso.getNome());
        System.out.println("\nCÓDIGO......: " + curso.getCodigoCompartilhavel());
        System.out.println("CURSO.......: " + curso.getNome());
        System.out.println("DESCRIÇÃO...: " + curso.getDescricao());
        System.out.println("DATA DE INÍCIO: " + curso.getDataInicioFormatada());
        
        if (jaInscrito) {
            System.out.println("\n VOCÊ JÁ ESTÁ INSCRITO NESTE CURSO!");
        } else if (curso.getEstado() != 0) {
            System.out.println("\n ESTE CURSO NÃO ESTÁ ACEITANDO INSCRIÇÕES!");
        } else if (vagasRestantes <= 0) {
            System.out.println("\n ESTE CURSO ESTÁ LOTADO!");
        } else {
            System.out.printf("\n CURSO DISPONÍVEL! Vagas: %d\n", vagasRestantes);
            System.out.println("\n(A) Fazer minha inscrição");
        }
        
        System.out.println("\n(R) Retornar");
        System.out.print("\nOpção: ");
        
        String entrada = console.nextLine().trim().toUpperCase();
        return entrada.isEmpty() ? ' ' : entrada.charAt(0);
    }
    
    // Detalhes do curso para cancelar inscrição
    public char mostraDetalhesCursoCancelamento(Curso curso) {
        ConsoleUtils.limparTela();
        
        System.out.println("\n\nEntrePares 1.0");
        System.out.println("-----------------");
        System.out.println("> Início > Minhas inscrições > " + curso.getNome());
        System.out.println("\nCÓDIGO......: " + curso.getCodigoCompartilhavel());
        System.out.println("CURSO.......: " + curso.getNome());
        System.out.println("DESCRIÇÃO...: " + curso.getDescricao());
        System.out.println("DATA DE INÍCIO: " + curso.getDataInicioFormatada());
        
        System.out.println("\n(A) Cancelar minha inscrição");
        System.out.println("\n(R) Retornar");
        System.out.print("\nOpção: ");
        
        String entrada = console.nextLine().trim().toUpperCase();
        return entrada.isEmpty() ? ' ' : entrada.charAt(0);
    }
    
    // Menu para dono do curso gerenciar inscritos
    public char mostraMenuGerenciarInscritos(Curso curso, List<Usuario> alunos, List<Inscricao> inscricoes) {
        ConsoleUtils.limparTela();
        
        System.out.println("\n\nEntrePares 1.0");
        System.out.println("-----------------");
        System.out.println("> Início > Meus cursos > " + curso.getNome() + " > Inscrições");
        
        if (alunos.isEmpty()) {
            System.out.println("\nNenhum aluno inscrito.");
        } else {
            System.out.println();
            for (int i = 0; i < alunos.size(); i++) {
                Usuario u = alunos.get(i);
                System.out.printf("(%d) %s - %s\n", i + 1, u.getNome(), u.getEmail());
            }
        }
        
        System.out.println("\n(A) Exportar lista (CSV)");
        System.out.println("\n(R) Retornar");
        System.out.print("\nOpção: ");
        
        String entrada = console.nextLine().trim().toUpperCase();
        return entrada.isEmpty() ? ' ' : entrada.charAt(0);
    }
    
    // Menu para gerenciar um aluno específico
    public char mostraMenuGerenciarAluno(Usuario aluno, Curso curso) {
        ConsoleUtils.limparTela();
        
        System.out.println("\n\nEntrePares 1.0");
        System.out.println("-----------------");
        System.out.println("> Início > Meus cursos > " + curso.getNome() + " > Aluno");
        System.out.println("\nNOME: " + aluno.getNome());
        System.out.println("EMAIL: " + aluno.getEmail());
        System.out.println("\n(A) Cancelar inscrição");
        System.out.println("\n(R) Retornar");
        System.out.print("\nOpção: ");
        
        String entrada = console.nextLine().trim().toUpperCase();
        return entrada.isEmpty() ? ' ' : entrada.charAt(0);
    }
    
    public String leCodigoBusca() {
        System.out.print("\nDigite o código do curso: ");
        return console.nextLine().trim();
    }
    
    public int selecionaAluno(int maxAlunos) {
        System.out.print("\nNúmero do aluno: ");
        try {
            int opcao = Integer.parseInt(console.nextLine());
            if (opcao >= 1 && opcao <= maxAlunos) {
                return opcao - 1;
            }
        } catch (NumberFormatException e) {}
        return -1;
    }
    
    public boolean confirma(String mensagem) {
        System.out.print("\n" + mensagem + " (S/N): ");
        return console.nextLine().trim().equalsIgnoreCase("S");
    }
    
    public void exibeMensagem(String msg) {
        System.out.println("\n" + msg);
        ConsoleUtils.pausar();
    }
}