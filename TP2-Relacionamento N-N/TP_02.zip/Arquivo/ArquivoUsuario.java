package Arquivo;

import java.util.List;

import Entidades.Curso;
import Entidades.Usuario;
import Estruturas.HashExtensivel;
import Pares.ParEmailID;

public class ArquivoUsuario extends Arquivo<Usuario> {

    private HashExtensivel<ParEmailID> indiceIndiretoEmail;

    public ArquivoUsuario() throws Exception {
        super("usuarios", Usuario.class.getConstructor());

        indiceIndiretoEmail = new HashExtensivel<>(
                ParEmailID.class.getConstructor(),
                4,
                "Dados/usuarios/emailUsuario.d.db",
                "Dados/usuarios/emailUsuario.c.db");
    }

    public Usuario read(String email) throws Exception {
        ParEmailID pBusca = new ParEmailID(email, -1);
        ParEmailID pEncontrado = indiceIndiretoEmail.read(pBusca.hashCode());

        if (pEncontrado != null && pEncontrado.getEmail().equalsIgnoreCase(email)) {
            return super.read(pEncontrado.getID());
        }
        return null;
    }

    @Override
    public int create(Usuario obj) throws Exception {
        Usuario existente = read(obj.getEmail());
        if (existente != null) {
            throw new Exception("Email já cadastrado.");
        }

        int id = super.create(obj);
        obj.setId(id);
        indiceIndiretoEmail.create(new ParEmailID(obj.getEmail(), id));
        return id;
    }

    @Override
    public boolean update(Usuario obj) throws Exception {
        Usuario antigo = super.read(obj.getId());
        if (antigo == null)
            return false;

        if (!antigo.getEmail().equalsIgnoreCase(obj.getEmail())) {
            Usuario existente = read(obj.getEmail());
            if (existente != null && existente.getId() != obj.getId()) {
                throw new Exception("Email já cadastrado.");
            }
        }

        if (super.update(obj)) {
            if (!antigo.getEmail().equalsIgnoreCase(obj.getEmail())) {
                ParEmailID pAntigo = new ParEmailID(antigo.getEmail(), antigo.getId());
                indiceIndiretoEmail.delete(pAntigo.hashCode());
                indiceIndiretoEmail.create(new ParEmailID(obj.getEmail(), obj.getId()));
            }
            return true;
        }

        return false;
    }

    @Override
    public boolean delete(int id) throws Exception {
        // 1. Abre o arquivo de cursos para fazer a verificação
        ArquivoCurso arqCursos = new ArquivoCurso();

        // 2. Tenta ler os cursos do usuário
        List<Curso> cursosDoUsuario = arqCursos.readAll(id);

        // 3. Verifica se há cursos ATIVOS (estado 0 ou 1)
        boolean temCursosAtivos = cursosDoUsuario.stream()
                .anyMatch(c -> c.getEstado() == 0 || c.getEstado() == 1);

        if (temCursosAtivos) {
            throw new Exception("Este usuário não pode ser excluído pois possui cursos ativos vinculados.");
        }

        // 4. Se só tiver cursos inativos (concluídos/cancelados), exclui eles também
        for (Curso c : cursosDoUsuario) {
            arqCursos.delete(c.getId());
        }

        // 5. Exclui o usuário
        Usuario u = super.read(id); // Cast para garantir o tipo
        if (u == null)
            return false;

        if (super.delete(id)) {
            // Seguindo o padrão que você usou no ArquivoCurso:
            // 1. Cria o par com os dados do usuário recuperado
            // 2. Passa o hashCode para o índice hash (se for HashExtensivel)
            ParEmailID pDelete = new ParEmailID(u.getEmail(), u.getId());
            return indiceIndiretoEmail.delete(pDelete.hashCode());
        }

        return false;
    }
}
