package Controles;

import Arquivo.ArquivoCurso;
import Entidades.Curso;
import Views.VisaoBuscaCurso;

public class ControleBuscaCurso {

    private ArquivoCurso arqCursos;
    private VisaoBuscaCurso visao;

    public ControleBuscaCurso() {
        try {
            this.arqCursos = new ArquivoCurso();
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.visao = new VisaoBuscaCurso();
    }

    public void executa() {
        String codigo;
        do {
            codigo = visao.leCodigo();
            if (!codigo.equalsIgnoreCase("R")) {
                try {
                    Curso cursoEncontrado = arqCursos.readByCodigo(codigo);
                    visao.mostraCursoEncontrado(cursoEncontrado);
                } catch (Exception e) {
                    System.out.println("Erro ao buscar o curso: " + e.getMessage());
                }
            }
        } while (!codigo.equalsIgnoreCase("R"));
    }
}