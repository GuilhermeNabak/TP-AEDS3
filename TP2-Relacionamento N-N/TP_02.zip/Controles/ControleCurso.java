package Controles;

import java.util.Comparator;
import java.util.List;
import Arquivo.ArquivoCurso;
import Entidades.Curso;
import Entidades.Usuario;
import Menus.ConsoleUtils;
import Views.VisaoCurso;

public class ControleCurso {

    private ArquivoCurso arqCursos;
    private VisaoCurso visao;
    private Usuario usuarioLogado;

    public ControleCurso(Usuario usuarioLogado) {
        try {
            this.arqCursos = new ArquivoCurso();
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.visao = new VisaoCurso();
        this.usuarioLogado = usuarioLogado;
    }

    public void executa() {
        String opcao;
        do {
            List<Curso> cursos = null;
            try {
                cursos = arqCursos.readAll(usuarioLogado.getId());
            } catch (Exception e) {
                visao.exibeMensagem("Erro ao ler os cursos: " + e.getMessage());
                cursos = new java.util.ArrayList<>();
            }

            cursos.sort(Comparator.comparing(Curso::getNome));
            opcao = visao.mostraMenuPrincipalCursos(cursos);

            switch (opcao) {
                case "N":
                    incluirCurso();
                    break;
                case "R":
                    break;
                default:
                    try {
                        int numCurso = Integer.parseInt(opcao) - 1;
                        if (numCurso >= 0 && numCurso < cursos.size()) {
                            gerenciarCurso(cursos.get(numCurso));
                        } else {
                            visao.exibeMensagem("Opção inválida!");
                        }
                    } catch (NumberFormatException e) {
                        visao.exibeMensagem("Opção inválida!");
                    }
                    break;
            }
        } while (!opcao.equals("R"));
    }

    private void gerenciarCurso(Curso curso) {
        char opcao;
        do {
            opcao = visao.mostraMenuDetalheCurso(curso);
            switch (opcao) {
                case 'A':
                    visao.exibeMensagem("Funcionalidade de gerenciar inscrições será implementada no TP2");
                    break;
                case 'B':
                    alterarCurso(curso);
                    break;
                case 'C':
                    encerrarInscricoes(curso);
                    break;
                case 'D':
                    concluirCurso(curso);
                    break;
                case 'E':
                    if (cancelarOuExcluirCurso(curso)) {
                        return;
                    }
                    break;
                case 'R':
                    break;
                default:
                    visao.exibeMensagem("Opção inválida!");
                    break;
            }
        } while (opcao != 'R');
    }

    private void incluirCurso() {
        Curso novoCurso = visao.leCurso();
        novoCurso.setIdUsuario(usuarioLogado.getId());
        novoCurso.setEstado(0); // Começa ativo e recebendo inscrições
        
        try {
            arqCursos.create(novoCurso);
            visao.exibeMensagem("Curso \"" + novoCurso.getNome() + "\" criado com sucesso!");
        } catch (Exception e) {
            visao.exibeMensagem("Erro ao criar curso: " + e.getMessage());
        }
    }

    private void alterarCurso(Curso curso) {
        // Só permite alterar se o curso não estiver concluído ou cancelado
        if (curso.getEstado() >= 2) {
            visao.exibeMensagem("Cursos concluídos ou cancelados não podem ser alterados.");
            return;
        }
        
        visao.leAlteracaoCurso(curso);
        try {
            arqCursos.update(curso);
            visao.exibeMensagem("Curso alterado com sucesso!");
        } catch (Exception e) {
            visao.exibeMensagem("Erro ao alterar curso: " + e.getMessage());
        }
    }

    private void encerrarInscricoes(Curso curso) {
        if (curso.getEstado() != 0) {
            visao.exibeMensagem("Este curso não está com inscrições abertas.");
            return;
        }
        
        curso.setEstado(1);
        try {
            arqCursos.update(curso);
            visao.exibeMensagem("Inscrições encerradas para este curso.");
        } catch (Exception e) {
            visao.exibeMensagem("Erro ao encerrar inscrições: " + e.getMessage());
        }
    }

    private void concluirCurso(Curso curso) {
        if (curso.getEstado() == 2) {
            visao.exibeMensagem("Curso já está concluído.");
            return;
        }
        
        curso.setEstado(2);
        try {
            arqCursos.update(curso);
            visao.exibeMensagem("Curso marcado como concluído.");
        } catch (Exception e) {
            visao.exibeMensagem("Erro ao concluir curso: " + e.getMessage());
        }
    }

    private boolean cancelarOuExcluirCurso(Curso curso) {
        // Aqui no TP1, como não temos alunos, podemos excluir diretamente
        // No TP2, precisará verificar se há inscritos
        if (visao.confirmaExclusao()) {
            try {
                // Verifica se tem inscritos (no TP2)
                boolean temInscritos = false; // placeholder
                
                if (temInscritos) {
                    curso.setEstado(3); // Apenas cancela
                    arqCursos.update(curso);
                    visao.exibeMensagem("Curso cancelado (mantido no sistema devido a inscrições existentes).");
                } else {
                    arqCursos.delete(curso.getId());
                    visao.exibeMensagem("Curso excluído com sucesso!");
                    return true;
                }
            } catch (Exception e) {
                visao.exibeMensagem("Erro ao excluir/cancelar curso: " + e.getMessage());
            }
        }
        return false;
    }
}