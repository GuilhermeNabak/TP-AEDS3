package Pares;

import java.io.*;
import java.util.Objects;
import Registros.RegistroHashExtensivel;

public class ParCodigoCurso implements RegistroHashExtensivel<ParCodigoCurso> {

    private String codigo;
    private int idCurso;
    private final short TAMANHO = 14;

    public ParCodigoCurso() {
        this("", -1);
    }

    public ParCodigoCurso(String codigo, int idCurso) {
        this.codigo = String.format("%-10.10s", codigo);
        this.idCurso = idCurso;
    }

    public String getCodigo() { return this.codigo.trim(); }
    public int getIdCurso() { return this.idCurso; }

    @Override
    public short size() { return TAMANHO; }

    @Override
    public int hashCode() {
        return this.codigo.trim().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        ParCodigoCurso that = (ParCodigoCurso) obj;
        return Objects.equals(this.getCodigo(), that.getCodigo());
    }

    @Override
    public byte[] toByteArray() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        dos.write(this.codigo.getBytes("UTF-8"));
        dos.writeInt(this.idCurso);
        return baos.toByteArray();
    }

    @Override
    public void fromByteArray(byte[] ba) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(ba);
        DataInputStream dis = new DataInputStream(bais);
        byte[] bufferCodigo = new byte[10];
        dis.read(bufferCodigo);
        this.codigo = new String(bufferCodigo, "UTF-8");
        this.idCurso = dis.readInt();
    }
}