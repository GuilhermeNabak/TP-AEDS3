package Pares;

import java.io.*;
import Registros.RegistroArvoreBMais;

public class ParUsuarioCurso implements RegistroArvoreBMais<ParUsuarioCurso> {

    private int idUsuario;
    private int idCurso;
    private final short TAMANHO = 8;

    public ParUsuarioCurso() {
        this(-1, -1);
    }

    public ParUsuarioCurso(int idUsuario, int idCurso) {
        this.idUsuario = idUsuario;
        this.idCurso = idCurso;
    }

    public int getIdUsuario() { return this.idUsuario; }
    public int getIdCurso() { return this.idCurso; }

    @Override
    public short size() { return this.TAMANHO; }

    @Override
    public ParUsuarioCurso clone() {
        return new ParUsuarioCurso(this.idUsuario, this.idCurso);
    }

    @Override
    public int compareTo(ParUsuarioCurso outro) {
        if (this.idUsuario != outro.idUsuario) {
            return this.idUsuario - outro.idUsuario;
        }
        return (this.idCurso == -1) ? 0 : this.idCurso - outro.idCurso;
    }

    @Override
    public byte[] toByteArray() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        dos.writeInt(this.idUsuario);
        dos.writeInt(this.idCurso);
        return baos.toByteArray();
    }

    @Override
    public void fromByteArray(byte[] ba) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(ba);
        DataInputStream dis = new DataInputStream(bais);
        this.idUsuario = dis.readInt();
        this.idCurso = dis.readInt();
    }
}